<?php
// Global init (embed relaxed by default)
if (!defined('EMBED_STRICT')) define('EMBED_STRICT', false);
@mb_internal_encoding('UTF-8');
define('DATA_DIR', __DIR__ . '/../data');
define('USERDATA_DIR', __DIR__ . '/../userdata');
define('DESKTOP_EMBED_PARAM', 'inapp');
if (!is_dir(DATA_DIR)) @mkdir(DATA_DIR, 0775, true);
if (!is_dir(USERDATA_DIR)) @mkdir(USERDATA_DIR, 0775, true);
if (session_status() === PHP_SESSION_NONE) { @session_start(['cookie_httponly'=>true, 'cookie_samesite'=>'Lax']); }
function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function csrf_token(){ if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16)); return $_SESSION['csrf']; }
function csrf_check(){ if (!isset($_POST['csrf']) || !isset($_SESSION['csrf']) || $_POST['csrf'] !== $_SESSION['csrf']) { http_response_code(400); exit('Geçersiz istek (CSRF).'); } }
function require_desktop_embed($app=''){ if(!EMBED_STRICT) return; if(isset($_GET[DESKTOP_EMBED_PARAM]) && $_GET[DESKTOP_EMBED_PARAM]==='1') return;
  $dir=str_replace('\\','/', dirname($_SERVER['SCRIPT_NAME']??'')); $target=($dir===''||$dir==='/')?'index.php':'../index.php';
  if($app===''){ $parts=explode('/',trim($dir,'/')); $guess=end($parts); $app=($guess==='admin'?'admin':($guess==='auth'?'login':'app')); }
  header('Location: '.$target.'?app='.rawurlencode($app)); exit; }
