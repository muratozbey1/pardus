<?php
require_once __DIR__ . '/init.php';
define('PAGES_FILE', DATA_DIR . '/pages.json');
function pages_bootstrap(){ if(!file_exists(PAGES_FILE)) file_put_contents(PAGES_FILE, json_encode(array('next_id'=>1,'pages'=>array()), JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)); }
function pages_read(){ pages_bootstrap(); $raw = @file_get_contents(PAGES_FILE); $data = $raw ? json_decode($raw,true) : null; if(!is_array($data)) $data=array('next_id'=>1,'pages'=>array()); return $data; }
function pages_write($data){ $json=json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT); $tmp=PAGES_FILE.'.tmp'; $fp=@fopen($tmp,'wb'); if(!$fp) die('pages_write: Yazılamadı'); @flock($fp,LOCK_EX); @fwrite($fp,$json); @fflush($fp); @flock($fp,LOCK_UN); @fclose($fp); @rename($tmp,PAGES_FILE); }
function page_get($id){ $all=pages_read(); foreach($all['pages'] as $p) if((int)$p['id']===(int)$id) return $p; return null; }
function page_get_by_slug($slug){ $all=pages_read(); foreach($all['pages'] as $p) if((isset($p['slug'])?$p['slug']:'')===$slug) return $p; return null; }
function page_save($id, $title, $slug, $html){
  $all=pages_read(); if($id){ foreach($all['pages'] as &$p){ if((int)$p['id']===(int)$id){ $p['title']=$title; $p['slug']=$slug; $p['html']=$html; $p['updated_at']=date('c'); pages_write($all); return $p; } } }
  $pid=(int)(isset($all['next_id'])?$all['next_id']:1); $all['next_id']=$pid+1; $p=array('id'=>$pid,'title'=>$title,'slug'=>$slug,'html'=>$html,'created_at'=>date('c'),'updated_at'=>date('c')); $all['pages'][]=$p; pages_write($all); return $p;
}
function page_delete($id){ $all=pages_read(); $new=array(); foreach($all['pages'] as $p){ if((int)$p['id']!== (int)$id) $new[]=$p; } $all['pages']=$new; pages_write($all); }
