<?php
require_once __DIR__ . '/init.php';
define('SETTINGS_FILE', DATA_DIR . '/settings.json');
function settings_defaults(){ return array('verify_enabled'=>false,'smtp'=>array('host'=>'','port'=>587,'secure'=>'tls','user'=>'','pass'=>'','from'=>'no-reply@example.com','from_name'=>'SoftDesk Bildirim')); }
function settings_read(){ if (!file_exists(SETTINGS_FILE)) { @file_put_contents(SETTINGS_FILE, json_encode(settings_defaults(), JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)); } $raw = @file_get_contents(SETTINGS_FILE); $arr = $raw ? json_decode($raw, true) : null; if (!is_array($arr)) $arr = array(); return array_replace_recursive(settings_defaults(), $arr); }
function settings_write($data){ $all = array_replace_recursive(settings_defaults(), $data); $tmp = SETTINGS_FILE.'.tmp'; $fp = @fopen($tmp,'wb'); if($fp){ @flock($fp,LOCK_EX); @fwrite($fp,json_encode($all,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)); @fflush($fp); @flock($fp,LOCK_UN); @fclose($fp); @rename($tmp,SETTINGS_FILE); } }
function settings_get($key, $default=null){ $s=settings_read(); return isset($s[$key])?$s[$key]:$default; }
