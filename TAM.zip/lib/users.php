<?php
require_once __DIR__ . '/init.php';
define('USERS_FILE', DATA_DIR . '/users.json');

function users_bootstrap(){
  if (!file_exists(USERS_FILE)) {
    @file_put_contents(USERS_FILE, json_encode(['next_id'=>1,'users'=>[]], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
  }
  $raw = @file_get_contents(USERS_FILE);
  $data = $raw ? json_decode($raw, true) : null;
  if (!is_array($data)) $data = ['next_id'=>1,'users'=>[]];

  $hasAdmin = false;
  foreach($data['users'] as $u){
    if(isset($u['email']) && strtolower($u['email'])==='admin@local'){ $hasAdmin=true; break; }
  }
  if(!$hasAdmin){
    $user = [
      'id' => (int)$data['next_id'],
      'role' => 'admin',
      'first_name' => 'Sistem',
      'last_name' => 'Yöneticisi',
      'email' => 'admin@local',
      'phone' => '',
      'city'  => '',
      'username' => 'admin',
      'pass_hash' => password_hash('Admin123!', PASSWORD_DEFAULT),
      'is_verified' => 1,
      'created_at' => date('c'),
      'updated_at' => date('c'),
      'last_login_at' => null
    ];
    $data['next_id'] = (int)$data['next_id'] + 1;
    $data['users'][] = $user;
    @file_put_contents(USERS_FILE, json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
    $udir = USERDATA_DIR . '/admin'; if(!is_dir($udir)) @mkdir($udir, 0775, true);
  }
}

function users_read(){ users_bootstrap(); $raw=@file_get_contents(USERS_FILE); $data=$raw?json_decode($raw,true):null; if(!is_array($data)) $data=['next_id'=>1,'users'=>[]]; return $data; }
function users_write($data){ $json=json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT); $tmp=USERS_FILE.'.tmp'; $fp=@fopen($tmp,'wb'); if(!$fp) die('users_write: Yazılamadı'); @flock($fp, LOCK_EX); @fwrite($fp, $json); @fflush($fp); @flock($fp, LOCK_UN); @fclose($fp); @rename($tmp, USERS_FILE); }
function user_by_email($email){ $all=users_read(); foreach($all['users'] as $u){ if(strtolower($u['email']??'')===strtolower($email)) return $u; } return null; }
function user_by_id($id){ $all=users_read(); foreach($all['users'] as $u){ if((int)$u['id']===(int)$id) return $u; } return null; }
function login_user_by_id($id){ $_SESSION['uid']=$id; }
function logout_user(){ $_SESSION = []; if (ini_get('session.use_cookies')) { $p=session_get_cookie_params(); setcookie(session_name(), '', time()-42000, $p['path'],$p['domain'],$p['secure'],$p['httponly']); } @session_destroy(); }
