<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/users.php';
function admin_logged_in(){
  if (!empty($_SESSION['admin_uid'])) {
    $u = user_by_id((int)$_SESSION['admin_uid']);
    return $u && isset($u['role']) && $u['role']==='admin' ? $u : null;
  }
  return null;
}
function admin_require(){
  $u = admin_logged_in();
  if(!$u){
    $q = DESKTOP_EMBED_PARAM.'=1';
    header('Location: ../admin/login.php?'.$q);
    exit;
  }
  return $u;
}
function admin_login_user($u){
  $_SESSION['uid'] = (int)$u['id']; // opsiyonel: genel oturum
  $_SESSION['admin_uid'] = (int)$u['id']; // admin oturumu
  $_SESSION['is_admin'] = 1;
}
function admin_logout(){
  unset($_SESSION['admin_uid'], $_SESSION['is_admin']);
}
