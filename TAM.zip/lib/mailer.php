<?php
declare(strict_types=1);
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/users.php';
function send_mail_verify(string $toEmail, string $firstName, string $verifyUrl): bool {
  $subj = 'Hesabını doğrula';
  $html = '<p>Merhaba '.esc($firstName).',</p><p>Hesabını aktifleştirmek için aşağıdaki linke tıkla:</p><p><a href="'.esc($verifyUrl).'">'.esc($verifyUrl).'</a></p>';
  $smtp = settings_get_smtp();
  if (function_exists('mail')) {
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $from = (string)($smtp['from'] ?? 'no-reply@example.com'); $fromName=(string)($smtp['from_name'] ?? 'Bildirim');
    $headers .= "From: ".$fromName." <".$from.">\r\n";
    return @mail($toEmail, '=?UTF-8?B?'.base64_encode($subj).'?=', $html, $headers);
  }
  outbox_log("VERIFY to={$toEmail} url={$verifyUrl}");
  return true;
}
