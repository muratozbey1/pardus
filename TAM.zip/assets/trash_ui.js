/* trash_ui.js v1.7 — User-only, colored buttons, robust restore refresh, no meta footer */
(function(){
  if (window.__TRASH_UI_17__) return; window.__TRASH_UI_17__ = true;

  const css = `
  .trash-wrap{padding:8px;color:#e6e9ee;font-size:13px}
  .trash-row{display:flex;align-items:center;gap:10px;padding:6px 8px;border-bottom:1px solid #232732}
  .trash-row .typ{width:18px;text-align:center;opacity:.9}
  .trash-row .meta{flex:1;display:flex;flex-direction:column}
  .trash-row .meta .name{font-weight:600}
  .trash-row .meta .sub{opacity:.7;font-size:12px}
  .trash-row .act{display:flex;gap:8px}
  .trash-empty{opacity:.7; padding:6px 0 10px 0}
  .trash-toolbar{display:flex;gap:8px;justify-content:flex-end;margin-bottom:6px}
  .btn{background:#22293a;border:1px solid #2a2f3b;border-radius:8px;color:#e6e9ee;padding:6px 10px;cursor:pointer}
  .btn-restore{background:#1f3d2b;border-color:#335a42}
  .btn-restore:hover{filter:brightness(1.1)}
  .btn-del{background:#3a2323;border-color:#5a3434}
  .btn-del:hover{filter:brightness(1.1)}
  .btn-refresh{background:#1f2c3d;border-color:#334b5a}
  .btn-empty{background:#3a321f;border-color:#5a4d33}
  `;
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  function fmtDate(iso){
    try{ const d = new Date(iso); if(!isFinite(d)) return iso||'';
      const dd = String(d.getDate()).padStart(2,'0');
      const M = ['Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'][d.getMonth()];
      const hh = String(d.getHours()).padStart(2,'0'), mm=String(d.getMinutes()).padStart(2,'0');
      return `${dd} ${M} ${d.getFullYear()} ${hh}:${mm}`;
    }catch(_){ return iso||''; }
  }
  function esc(s){ return String(s||'').replace(/[&<>"]/g, m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[m])); }

  async function list(owner){
    const url = `api_trash.php?action=list&owner=${encodeURIComponent(owner)}&t=${Date.now()}`;
    const r = await fetch(url, {credentials:'same-origin', cache:'no-store'});
    const j = await r.json().catch(()=>({ok:false,error:'Yanıt okunamadı'}));
    if (!j || !j.ok) return {ok:false, items:[], error:j && j.error};
    return {ok:true, items: j.items||[]};
  }
  async function restore(tid, owner){
    const fd = new FormData(); fd.append('action','restore'); fd.append('tid',tid); fd.append('owner',owner);
    const r = await fetch('api_trash.php', {method:'POST', body:fd, credentials:'same-origin'});
    return await r.json().catch(()=>({ok:false,error:'Yanıt okunamadı'}));
  }
  async function delperm(tid, owner){
    const fd = new FormData(); fd.append('action','delete_permanent'); fd.append('tid',tid); fd.append('owner',owner);
    const r = await fetch('api_trash.php', {method:'POST', body:fd, credentials:'same-origin'});
    return await r.json().catch(()=>({ok:false,error:'Yanıt okunamadı'}));
  }
  async function empty(owner){
    const fd = new FormData(); fd.append('action','empty'); fd.append('owner',owner);
    const r = await fetch('api_trash.php', {method:'POST', body:fd, credentials:'same-origin'});
    return await r.json().catch(()=>({ok:false,error:'Yanıt okunamadı'}));
  }

  function iconFor(t){
    if (t.type==='folder') return "<i class='fa-regular fa-folder'></i>";
    return "<i class='fa-solid fa-up-right-from-square'></i>";
  }

  function renderEmpty(container){
    const em = document.createElement('div'); em.className='trash-empty'; em.textContent='(boş)';
    container.appendChild(em);
  }

  async function renderTrashInto(container){
    const U = (window.SOFTDESK_USER||{});
    const owner = (U && U.logged && U.email) ? U.email : '';

    const wrap = document.createElement('div'); wrap.className='trash-wrap';
    const tb = document.createElement('div'); tb.className='trash-toolbar';
    const bRefresh = document.createElement('button'); bRefresh.className='btn btn-refresh'; bRefresh.textContent='Yenile';
    const bEmpty   = document.createElement('button'); bEmpty.className='btn btn-empty'; bEmpty.textContent='Çöpü Boşalt';
    tb.appendChild(bRefresh); tb.appendChild(bEmpty);
    wrap.appendChild(tb);

    const secTitle = document.createElement('div'); secTitle.className='trash-sec'; secTitle.textContent='Çöp Kutum';
    wrap.appendChild(secTitle);

    const listBox = document.createElement('div');
    wrap.appendChild(listBox);

    if (!owner){
      renderEmpty(listBox);
      const info = document.createElement('div'); info.className='trash-empty';
      info.textContent = 'Çöp kutusunu görmek için giriş yapmalısınız.';
      wrap.appendChild(info);
      container.innerHTML=''; container.appendChild(wrap);
      return;
    }

    async function reload(){
      listBox.innerHTML='';
      const res = await list(owner);
      const items = res.items||[];
      if (!items.length){ renderEmpty(listBox); return; }
      items.forEach(t=>{
        const row = document.createElement('div'); row.className='trash-row';
        const name = t.type==='folder' ? (t.name || 'Klasör') : (t.title || 'Kısayol');
        const sub = `${t.type==='folder'?'Klasör':'Kısayol'} • ${fmtDate(t.deleted_at)}`;
        row.innerHTML = `
          <div class="typ">${iconFor(t)}</div>
          <div class="meta"><div class="name">${esc(name)}</div><div class="sub">${esc(sub)}</div></div>
          <div class="act">
            <button class="btn btn-restore" data-restore="${esc(t.tid)}">Geri Al</button>
            <button class="btn btn-del" data-delperm="${esc(t.tid)}">Kalıcı Sil</button>
          </div>`;
        row.querySelector('[data-restore]').addEventListener('click', async ()=>{
          const j = await restore(t.tid, owner);
          if (j && j.ok){
            row.remove();
            if (!listBox.querySelector('.trash-row') && !listBox.querySelector('.trash-empty')) renderEmpty(listBox);
            try{ if (window.loadFolders) await window.loadFolders(); }catch(_){}
            try{
              if (window.showToast) window.showToast('Geri alındı','success');
              else console.log('[trash] restore ok');
            }catch(_){}
          } else {
            alert((j && j.error) || 'Geri alınamadı');
          }
        });
        row.querySelector('[data-delperm]').addEventListener('click', async ()=>{
          if (!confirm('Kalıcı silinsin mi?')) return;
          const j = await delperm(t.tid, owner);
          if (j && j.ok){
            row.remove();
            if (!listBox.querySelector('.trash-row') && !listBox.querySelector('.trash-empty')) renderEmpty(listBox);
          } else {
            alert((j && j.error) || 'Silinemedi');
          }
        });
        listBox.appendChild(row);
      });
    }

    bRefresh.addEventListener('click', reload);
    bEmpty.addEventListener('click', async ()=>{
      if (!confirm('Çöpü tamamen boşalt?')) return;
      const j = await empty(owner);
      if (j && j.ok){ reload(); }
      else alert(j && j.error || 'Boşaltılamadı');
    });

    await reload();
    container.innerHTML='';
    container.appendChild(wrap);
  }

  window.openTrashUI = function(forceReload){
    const id = 'trash_ui_win';
    var w;
    if (window.openWindowEx){
      const html = `<div id="trash_ui_container" style="width:100%;height:100%;overflow:auto"></div>`;
      w = window.openWindowEx({id, title:'Çöp Kutusu', html, w:640, h:420});
    } else { alert('Pencere yöneticisi yok'); return; }
    const container = w.querySelector('#trash_ui_container');
    renderTrashInto(container);
  };
})();