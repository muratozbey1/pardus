/* assets/alerts_matrix.js — make alerts/toasts colorful matrix-style */
(function(){
  if (window.__PARDUS_ALERTS_MATRIX__) return; window.__PARDUS_ALERTS_MATRIX__=true;

  const css = `
  .matrix-toast, .toast, .toastify, .notify, .alert {
    background: radial-gradient(120% 120% at 0% 0%, rgba(21,45,36,.95) 0%, rgba(10,18,15,.95) 65%);
    color: #b9ffca !important;
    border: 1px solid #1b4235 !important;
    box-shadow: 0 10px 30px rgba(0,0,0,.45), 0 0 0 1px #0a1f18 inset !important;
    border-radius: 12px !important;
    backdrop-filter: blur(2px);
  }
  .matrix-toast.success, .toast-success { color:#d7ffe4 !important; border-color:#1f6b54 !important; }
  .matrix-toast.warn,    .toast-warn    { color:#fff6c9 !important; border-color:#6b651f !important; }
  .matrix-toast.error,   .toast-error   { color:#ffd0d0 !important; border-color:#6b1f1f !important; }
  .matrix-toast .title { font-weight:700; letter-spacing:.2px; color:#8fffb1 }
  .matrix-toast .msg { opacity:.95 }
  `;
  const style = document.createElement('style'); style.textContent = css; document.head.appendChild(style);

  // Try to upgrade existing toasts/alerts by tagging classes
  const mo = new MutationObserver((muts)=>{
    for (const m of muts){
      m.addedNodes && m.addedNodes.forEach(n=>{
        if (!(n instanceof HTMLElement)) return;
        const cls = n.className? String(n.className): '';
        if (/toast|alert|notify/i.test(cls)){
          n.classList.add('matrix-toast');
        }
        // Deep children too
        n.querySelectorAll && n.querySelectorAll('[class*="toast"],[class*="alert"],[class*="notify"]').forEach(el=> el.classList.add('matrix-toast'));
      });
    }
  });
  mo.observe(document.documentElement, { childList:true, subtree:true });

  // If a global toast(msg, type) exists, shim colors
  if (typeof window.toast === 'function'){
    const orig = window.toast;
    window.toast = function(msg, type){
      const el = orig.apply(this, arguments);
      try{
        if (el && el.classList){
          el.classList.add('matrix-toast');
          if (type) el.classList.add(String(type));
        }
      }catch(_){}
      return el;
    };
  }
})();