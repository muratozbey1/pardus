/* assets/uploader.js — v3.2 (toolbar bind + logs) */
(function(){
function PardusSafeJSON(s){try{return JSON.parse(s);}catch(e){try{return JSON.parse(String(s||'').replace(/^[^\[{]+/, ''));}catch(e2){return {ok:false,error:'bad_json',raw:(s||'').slice(0,300)};}}}
  if (window.__PARDUS_UPLOADER_INIT__) return;
  window.__PARDUS_UPLOADER_INIT__ = true;

  const cfg = Object.assign({
    api: 'api.php',
    mountButton: true,
    buttonLabel: 'Dosya Seç',
    buttonTitle: 'Bu klasöre dosya yükle (Ctrl+U)',
    buttonTarget: null,
    globalDrop: 'target-only',
    afterUploadRefresh: true
  }, window.PardusUploaderConfig || {});

  let defaultTarget = (window.PardusCurrentFolder || window.PardusCurrentPath || '').toString();
  let oneShotTarget = null;

  function setDefaultTarget(t){ defaultTarget = (t||'').toString(); console.log('[Pardus] target =', defaultTarget); }
  function setOneShotTarget(t){ oneShotTarget = (t||'').toString(); }
  function getTarget(){ return (oneShotTarget || defaultTarget || '').toString(); }

  window.PardusUploadSetTarget = setDefaultTarget;
  window.PardusUploadHere = function(t){ setOneShotTarget(t); fileInput.click(); };
  window.PardusUploadGetTarget = getTarget;

  window.PardusUploadBindView = function(elOrSelector, folder){
    const el = (typeof elOrSelector === 'string') ? document.querySelector(elOrSelector) : elOrSelector;
    if (!el) return;
    const f = (folder||'').toString();
    const grid = document.querySelector('[data-upload-target]') || el;
    grid.setAttribute('data-upload-target', f);
    setDefaultTarget(f);
    if (cfg.mountButton) mountButton(el); // butonu özellikle bağlanan elemana ekle (toolbar)
  };

  const style = document.createElement('style');
  style.textContent = `
  .pardus-upload-btn{
    display:inline-flex; align-items:center; gap:8px; cursor:pointer; user-select:none;
    height:30px; padding:0 10px; border-radius:8px; border:1px solid #2a2f38; background:#1b1f28; color:#e6e9ee;
  }
  .pardus-upload-btn:hover{ filter:brightness(1.08); }
  .pardus-upload-progress{
    position:fixed; left:16px; bottom:16px; right:16px; height:12px; background:#1b1f28; z-index:9999;
    border:1px solid #2a2f38; border-radius:6px; overflow:hidden;
  }
  .pardus-upload-progress > div{ height:100%; width:0%; background:#198754; transition:width .2s; }
  .pardus-toast{
    position:fixed; bottom:36px; left:50%; transform:translateX(-50%); z-index:9999;
    background:#1b1f28; color:#e6e9ee; border:1px solid #2a2f38; padding:10px 14px; border-radius:10px;
    box-shadow:0 2px 8px rgba(0,0,0,.25); font:500 13px system-ui;
  }`;
  document.head.appendChild(style);

  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.multiple = true;
  fileInput.style.display = 'none';
  document.body.appendChild(fileInput);

  let btn = null;
  function mountButton(targetEl){
    if (btn) { try { btn.remove(); } catch(_){} } // Tekrar açılan klasörde yinelenmesin
    btn = document.createElement('button');
    btn.className = 'pardus-upload-btn';
    btn.title = cfg.buttonTitle || '';
    btn.innerHTML = `<span style="display:inline-block;width:14px;height:14px;border:2px solid currentColor;border-bottom:0;border-right:0;transform:rotate(45deg);margin-top:2px"></span>
                     <span>${cfg.buttonLabel}</span>`;
    (targetEl || document.body).appendChild(btn);
    btn.addEventListener('click', ()=>{
      if (!getTarget()) { showToast('Önce bir klasör açın'); return; }
      fileInput.click();
    });
  }

  if (cfg.mountButton && cfg.buttonTarget && document.querySelector(cfg.buttonTarget)) {
    mountButton(document.querySelector(cfg.buttonTarget));
  }

  document.addEventListener('keydown', (e)=>{
    if ((e.ctrlKey || e.metaKey) && (e.key === 'u' || e.key === 'U')) {
      e.preventDefault();
      if (!getTarget()) { showToast('Önce bir klasör açın'); return; }
      fileInput.click();
    }
  });

  fileInput.addEventListener('change', async ()=>{
    if (!fileInput.files || fileInput.files.length===0) return;
    await uploadFiles(fileInput.files, getTarget());
    fileInput.value = '';
    if (oneShotTarget) oneShotTarget = null;
  });

  function wireAttributeDropTargets(){
    const nodes = document.querySelectorAll('[data-upload-target]');
    nodes.forEach(node => {
      if (node.__uploadWired__) return;
      node.__uploadWired__ = true;
      node.addEventListener('dragover', e => { e.preventDefault(); });
      node.addEventListener('drop', e => {
        e.preventDefault();
        const t = (node.getAttribute('data-upload-target')||'').toString();
        const dt = e.dataTransfer;
        if (!t || !dt || !dt.files || !dt.files.length) return;
        uploadFiles(dt.files, t);
      });
    });
  }
  wireAttributeDropTargets();
  const mo = new MutationObserver(wireAttributeDropTargets);
  mo.observe(document.documentElement, {childList:true, subtree:true});

  function showToast(msg, ms=1600){
    const t = document.createElement('div'); t.className='pardus-toast'; t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(()=>{ t.remove(); }, ms);
  }

  async function uploadFiles(fileList, folder){
    const files = Array.from(fileList);
    if (!files.length) return;

    const prog = document.createElement('div');
    prog.className = 'pardus-upload-progress';
    const bar = document.createElement('div');
    prog.appendChild(bar);
    document.body.appendChild(prog);

    const fd = new FormData();
    fd.append('action','upload_files');
    fd.append('a','upload_files');
    fd.append('folder', folder || '');
    files.forEach(f => fd.append('files[]', f, f.name));

    await new Promise((resolve)=>{
      const xhr = new XMLHttpRequest();
      xhr.open('POST', cfg.api);
      xhr.withCredentials = true;
      xhr.setRequestHeader('X-Requested-With','XMLHttpRequest');
      xhr.upload.onprogress = (e)=>{
        if (e.lengthComputable) {
          const p = Math.round((e.loaded/e.total)*100);
          bar.style.width = p + '%';
        }
      };
      xhr.onreadystatechange = ()=>{
        if (xhr.readyState === 4) {
          setTimeout(()=>{ prog.remove(); }, 600);
          if (xhr.status>=200 && xhr.status<300) {
            try {
              const res = PardusSafeJSON(xhr.responseText);
              if (res && res.saved && res.saved.length) {
                showToast(`Yüklendi: ${res.saved.length} dosya`);
                if (cfg.afterUploadRefresh && typeof window.refreshFileList === 'function') {
                  try { window.refreshFileList(folder); } catch(_e){}
                }
                if (typeof window.onUploadDone === 'function') {
                  try { window.onUploadDone(res); } catch(_e){}
                }
              } else {
                showToast('Yükleme hatası');
                console.warn('Upload error:', res);
              }
            } catch(err){ showToast('Sunucu yanıtı okunamadı'); }
          } else {
            showToast('Yükleme başarısız (HTTP '+xhr.status+')');
          }
          resolve();
        }
      };
      xhr.send(fd);
    });
  }

  console.log('%cPardus Uploader v3.2 hazır','padding:4px 8px;background:#1b1f28;color:#e6e9ee;border:1px solid #2a2f38;border-radius:6px');
})();