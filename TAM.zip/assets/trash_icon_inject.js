/* Add a Trash icon to desktop grid */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  ready(function(){
    try{
      var grid = document.getElementById('grid'); if(!grid) return;
      if (document.querySelector('.item[data-id="trash"]')) return;
      var el = document.createElement('div'); el.className='item'; el.dataset.id='trash';
      el.innerHTML = "<div class='ficon'><i class='fa-regular fa-trash-can' style='color:#f87171'></i></div><div class='flabel'>Çöp Kutusu</div>";
      el.addEventListener('click', function(){ if (el._dragged) return; if (window.openTrashMini) window.openTrashMini(); else { var s=document.createElement('script'); s.src='assets/trash.js'; document.head.appendChild(s); s.onload=function(){ if(window.openTrashMini) window.openTrashMini(); }; } });
      grid.appendChild(el);
      // position helpers from index.js are available globally: dragify/place
      try{ if(window.dragify) dragify(el, 'trash'); if(window.place) place(el, 'trash', 0, 2); }catch(e){}
    }catch(e){}
  });
})();