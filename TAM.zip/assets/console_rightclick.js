/* assets/console_rightclick.js — add 'Konsolu Aç/Kapat' to right-click */
(function(){
  if (window.__PARDUS_CONSOLE_RCLICK__) return; window.__PARDUS_CONSOLE_RCLICK__=true;

  function toggleConsole(){
    try{
      const el = (window.PardusConsole && window.PardusConsole.element) || document.getElementById('pardusConsole');
      if (!el){ alert('Pardus Konsol bulunamadı'); return; }
      el.classList.toggle('hidden');
    }catch(_){}
  }

  // Try to inject into existing context menus when they appear
  const mo = new MutationObserver((muts)=>{
    muts.forEach(m=>{
      m.addedNodes && Array.from(m.addedNodes).forEach(n=>{
        if (!(n instanceof HTMLElement)) return;
        const isMenu = /ctx|context|menu/i.test(n.className||'') || n.getAttribute('role')==='menu';
        if (isMenu){
          // Insert a button at the top
          try{
            const btn = document.createElement('div');
            btn.textContent = '🖥️ Konsolu Aç/Kapat (Ctrl+Alt+C)';
            btn.style.cssText='padding:8px 10px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,.06)';
            btn.onclick = function(e){ e.stopPropagation(); toggleConsole(); if (n.remove) n.remove(); };
            n.insertBefore(btn, n.firstChild);
          }catch(_){}
        }
      });
    });
  });
  mo.observe(document.documentElement, {childList:true, subtree:true});

  // Fallback: show our minimal menu if no system menu appears
  document.addEventListener('contextmenu', (ev)=>{
    // If app spawns a menu, we'll also see it via MO within ~few ms. We'll display ours if nothing appears.
    setTimeout(()=>{
      const existing = document.querySelector('.ctx-menu, .context-menu, #ctx, #ctx-menu, #context, #context-menu');
      if (existing) return;
      const menu = document.createElement('div');
      menu.id='pc-ctx';
      menu.style.cssText='position:absolute;z-index:2147483647;left:'+ev.pageX+'px;top:'+ev.pageY+'px;background:#0b1411;border:1px solid #173b2f;border-radius:10px;min-width:240px;box-shadow:0 10px 30px rgba(0,0,0,.5)';
      const item = document.createElement('div');
      item.textContent='🖥️ Konsolu Aç/Kapat (Ctrl+Alt+C)';
      item.style.cssText='padding:10px 12px;cursor:pointer;color:#b9ffca';
      item.onclick = ()=>{ toggleConsole(); if (menu.remove) menu.remove(); };
      menu.appendChild(item);
      document.body.appendChild(menu);
      const hide = ()=>{ if (menu && menu.parentNode) menu.parentNode.removeChild(menu); };
      setTimeout(()=>{ document.addEventListener('click', hide, {once:true}); document.addEventListener('keydown', hide, {once:true}); }, 0);
    }, 80);
  }, true);
})();