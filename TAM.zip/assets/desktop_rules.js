/* Desktop rules: guests cannot create folders (show message) */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  ready(function(){
    var U = window.SOFTDESK_USER || {logged:false, role:'guest'};
    var ctxNew = document.getElementById('ctxNew');
    if (!ctxNew) return;
    if (!U.logged){
      // show message when clicked
      ctxNew.style.opacity = .75;
      ctxNew.onclick = function(e){ e.preventDefault(); e.stopPropagation(); alert('Klasör oluşturmak için giriş yapınız.'); };
    } else {
      // allow default handler (openNewFolderDialog)
      // make sure existing onclick remains; do nothing
    }
  });
})();