(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function showToast(msg, dur){
    dur = dur || 3500;
    var el = document.createElement('div');
    el.style.cssText = 'position:fixed;left:0;right:0;bottom:46px;display:flex;justify-content:center;pointer-events:none;z-index:20000';
    var inner = document.createElement('div');
    inner.textContent = msg;
    inner.style.cssText='background:rgba(20,24,32,.95);color:#e6e9ee;padding:10px 14px;border:1px solid #2a2f3b;border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,.45);font-weight:600;font-size:13px';
    el.appendChild(inner); document.body.appendChild(el);
    setTimeout(function(){ try{el.remove();}catch(e){} }, dur);
  }
  ready(function(){
    try{
      var key='SOFTDESK_TOAST';
      var v = localStorage.getItem(key);
      if (v==='login-ok'){ showToast('Başarılı giriş yaptınız', 3000); }
      else if (v==='logout-ok'){ showToast('Çıkış yapıldı', 3000); }
      if (v) localStorage.removeItem(key);
      window._showToast = showToast;
    }catch(e){}
  });
})();