/* Desktop links: open on dblclick; drop-to-folder; owner attr */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  const $=(s,c=document)=>c.querySelector(s), $$=(s,c=document)=>Array.from(c.querySelectorAll(s));
  function eh(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]));}
  const gridId='grid';
  function kPos(id){ return 'desk_pos_'+id; }
  function loadPos(key){ try{ const j=localStorage.getItem(kPos(key)); if(!j) return null; const o=JSON.parse(j); if(typeof o.x==='number'&&typeof o.y==='number') return o; }catch(_){ } return null; }
  function savePos(key,x,y){ try{ localStorage.setItem(kPos(key), JSON.stringify({x:x,y:y})); }catch(_){ } }
  function conf(x,y){ const grid=$('#'+gridId); const r=grid.getBoundingClientRect(); const mx=Math.max(10,r.width-96-10), my=Math.max(10,r.height-96-10); return {x:Math.min(mx,Math.max(10,x)), y:Math.min(my,Math.max(10,y))}; }
  function snap(v,st){ return Math.max(10, Math.round(v/st)*st); }
  function dragify(el,key){
    let down=false,moved=false,sx=0,sy=0,sl=0,st=0;
    el.addEventListener("pointerdown",(e)=>{down=true;moved=false;sx=e.clientX;sy=e.clientY;const r=el.getBoundingClientRect(), R=$('#'+gridId).getBoundingClientRect();sl=r.left-R.left;st=r.top-R.top; el.setPointerCapture(e.pointerId);});
    el.addEventListener("pointermove",(e)=>{ if(!down) return; const dx=e.clientX-sx, dy=e.clientY-sy; if(Math.abs(dx)+Math.abs(dy)>2) moved=true; const p=conf(sl+dx,st+dy); el.style.left=p.x+"px"; el.style.top=p.y+"px";});
    el.addEventListener("pointerup",(e)=>{ if(!down) return; down=false; const x=parseInt(el.style.left||"0",10), y=parseInt(el.style.top||"0",10); const s={x:snap(x,96), y:snap(y,96)}; el.style.left=s.x+"px"; el.style.top=s.y+"px"; savePos(key,s.x,s.y); if(moved){el._dragged=true; setTimeout(()=>el._dragged=false,40);} dropToFolder(el, e); });
  }
  function place(el,key,col,row){
    const p=loadPos(key); const x=p?p.x:10+col*96, y=p?p.y:10+row*96; el.style.left=x+"px"; el.style.top=y+"px";
  }
  function dropToFolder(el, e){
    const x = e.clientX, y = e.clientY;
    const folders = $$('.item[data-id^="f_"], .item[data-id^="fld-"]');
    for (const f of folders){
      const r = f.getBoundingClientRect();
      if (x>=r.left && x<=r.right && y>=r.top && y<=r.bottom){
        const id = el.dataset.linkId, owner = el.dataset.owner||'';
        const fid = f.dataset.id.replace(/^fld-/,'');
        if (!id || !fid) return;
        const fd = new FormData(); fd.append('action','move_link'); fd.append('id', id); fd.append('parent', fid);
        if (owner) fd.append('owner', owner);
        fetch('api.php', {method:'POST', body:fd, credentials:'same-origin'})
        .then(r=>r.json()).then(j=>{
          if(!j.ok){ alert(j.error||'Taşınamadı'); return; }
          if (window._showToast) window._showToast('Kısayol klasöre taşındı', 1800);
        }).catch(()=>alert('Ağ hatası'));
        return;
      }
    }
  }
  function iconHTML(spec){
    if(!spec) return "<span>🔗</span>";
    if(spec.startsWith('fa:')){
      let cls=spec.substring(3), colr=null; const p=cls.indexOf("|");
      if(p>-1){ colr=cls.substring(p+1); cls=cls.substring(0,p); }
      return "<i class='"+cls+"'"+(colr?(" style='color:"+colr+"'"):"")+"></i>";
    }
    return "<span>🔗</span>";
  }
  function createLinkIcon(link, col, row){
    const grid = $('#'+gridId);
    if (link.parent) return;
    const el = document.createElement('div'); el.className='item'; el.dataset.id='lnk-'+link.id; el.dataset.linkId=link.id; 
    const U = (window.SOFTDESK_USER||{}); el.dataset.owner = link.owner || U.email || '';
    el.innerHTML = "<div class='ficon'>"+iconHTML(link.icon||"fa:fa-solid fa-up-right-from-square|#8ab4f8")+"</div><div class='flabel'>"+eh(link.title||'Kısayol')+"</div>";
    el.addEventListener('dblclick', function(){ if (el._dragged) return; window.open(link.url, '_blank'); });
    grid.appendChild(el); dragify(el, 'lnk-'+link.id); place(el, 'lnk-'+link.id, col, row);
  }
  async function loadLinks(){
    try{
      const r = await fetch('api.php?action=list_links', {cache:'no-store', credentials:'same-origin'});
      const j = await r.json();
      if(!j || !Array.isArray(j.links)){ console.warn('list_links bad response', j); return; }
      let col=1, row=0;
      j.links.forEach(l=>{ createLinkIcon(l, col, row); row++; if ((row+1)*96 > (document.getElementById('grid').clientHeight-120)){ row=0; col++; } });
    }catch(err){ console.error('links load fail', err); }
  }
  window.openShortcutMini = function(){
    const html = `
    <style>
      .s-mini{padding:10px;font-size:12.5px}
      .s-mini .g{display:grid;grid-template-columns:110px 1fr;gap:8px;align-items:center}
      .s-mini label{color:#c7d0df}
      .s-mini input{width:100%;padding:8px;border-radius:8px;border:1px solid var(--line);background:#0f1115;color:#e6e9ee}
      .s-mini .tool{display:flex;gap:8px;justify-content:flex-end;margin-top:8px}
      .s-mini select{width:100%;padding:8px;border-radius:8px;border:1px solid var(--line);background:#0f1115;color:#e6e9ee}
      .s-mini .err{color:#ef4444;margin-top:4px;font-size:12px}
    </style>
    <form id="sForm" class="s-mini">
      <div class="g">
        <label>Başlık</label><input name="title" required placeholder="Örn: Pardus">
        <label>URL</label><input name="url" required placeholder="https://...">
        <label>İkon</label>
        <select name="icon">
          <option value="fa:fa-solid fa-up-right-from-square|#8ab4f8">Dış bağlantı</option>
          <option value="fa:fa-brands fa-chrome|#f59e0b">Chrome</option>
          <option value="fa:fa-brands fa-firefox|#f97316">Firefox</option>
          <option value="fa:fa-brands fa-github|#c084fc">GitHub</option>
          <option value="fa:fa-solid fa-globe|#22c55e">Globe</option>
          <option value="fa:fa-solid fa-bolt|#fde047">Bolt</option>
        </select>
      </div>
      <div id="serr" class="err"></div>
      <div class="tool">
        <button type="button" id="btnCancel" class="btn">Kapat</button>
        <button type="submit" class="btn">Oluştur</button>
      </div>
    </form>`;
    const w = openWindowEx({ id:'shortcut-mini', title:'Kısayol Oluştur', html:html, w:420, h:260 });
    const f = w.querySelector('#sForm'), cancel=w.querySelector('#btnCancel'), serr=w.querySelector('#serr');
    if (cancel) cancel.onclick = ()=>{ w.style.display='none'; };
    f.onsubmit = async function(e){
      e.preventDefault();
      serr.textContent='';
      const fd = new FormData(f); fd.append('action','create_link');
      const U = (window.SOFTDESK_USER||{}); if (U.email) fd.append('owner', U.email);
      let url = (f.url.value||'').trim();
      if (url && !/^https?:\/\//i.test(url)) { url = 'https://' + url; fd.set('url', url); }
      try{
        const r = await fetch('api.php', {method:'POST', body:fd, credentials:'same-origin'});
        const j = await r.json().catch(()=>({ok:false,error:'Sunucu yanıtı okunamadı'}));
        if(!j.ok){ serr.textContent = j.error||'Kısayol oluşturulamadı'; return; }
        if (window._showToast) window._showToast('Kısayol oluşturuldu', 1800);
        w.style.display='none';
        createLinkIcon({id:j.id,title:f.title.value,url:url,icon:f.icon.value,owner:U.email||''}, 1, 0);
      }catch(_){ serr.textContent='Ağ hatası'; }
    };
  };
  ready(loadLinks);
})();