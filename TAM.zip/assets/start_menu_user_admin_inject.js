/* Start menu injector (adds Uçbirim) */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function railName(txt){ try{ document.querySelector('.startmenu .rail .rname').textContent = txt; }catch(e){} }
  function ensureItem(id, html, onClick){
    var ul = document.getElementById('menuStatic') || document.querySelector('#menu .list');
    if(!ul) return null;
    var el = document.getElementById(id);
    if(!el){
      el = document.createElement('li'); el.className='it'; el.id=id; el.innerHTML = html;
      ul.insertBefore(el, document.getElementById('mExit') || null);
    }
    if (onClick) el.onclick = function(){ try{ document.getElementById('menu').classList.remove('open'); }catch(e){} onClick(); };
    return el;
  }
  function removeItem(id){ var el=document.getElementById(id); if(el && el.parentNode) el.parentNode.removeChild(el); }
  function setDisplay(id, show){ var el=document.getElementById(id); if(el) el.style.display = show ? '' : 'none'; }
  function injectUserHeader(U){
    try{
      var body = document.querySelector('#menu .body'); if(!body) return;
      var old = document.getElementById('userHead'); if(old) old.remove();
      if(!(U && U.logged)) return;
      var box = document.createElement('div'); box.id='userHead';
      box.style.cssText='display:flex;align-items:center;gap:10px;padding:8px 10px;border-bottom:1px solid var(--line);background:var(--bg3)';
      var ava = document.createElement('div');
      ava.style.cssText='width:28px;height:28px;border-radius:50%;background:#263040;display:grid;place-items:center;overflow:hidden';
      if (U.avatar_url){ ava.innerHTML = '<img src="'+U.avatar_url+'" alt="" style="width:100%;height:100%;object-fit:cover">'; }
      else { var ch=(U.name||'U').trim().charAt(0).toUpperCase(); ava.innerHTML='<div style="font-size:14px;color:#cfe1ff">'+ch+'</div>'; }
      var txt = document.createElement('div');
      txt.innerHTML = '<div style="font-weight:700">'+(U.name||'')+'</div><div style="font-size:12px;color:#9aa6b2">'+(U.email||'')+'</div>';
      box.appendChild(ava); box.appendChild(txt); body.insertBefore(box, body.firstChild);
    }catch(e){}
  }
  function dynScript(src, cb){
    if (document.querySelector('script[data-dyn="'+src+'"]')) { if(cb) cb(); return; }
    var s=document.createElement('script'); s.src=src; s.dataset.dyn=src; s.onload=function(){ if(cb) cb(); };
    document.head.appendChild(s);
  }
  function hookExit(){
    var ex = document.getElementById('mExit'); if(!ex) return;
    ex.addEventListener('click', function(ev){
      ev.preventDefault(); ev.stopPropagation();
      try{ document.getElementById('menu').classList.remove('open'); }catch(e){}
      try{ localStorage.setItem('SOFTDESK_TOAST','logout-ok'); }catch(e){}
      fetch('auth/logout.php?inapp=1', {cache:'no-store', credentials:'same-origin'}).finally(function(){ location.reload(); });
    }, {once:true});
  }
  document.addEventListener('DOMContentLoaded', function(){
    var U = (window.SOFTDESK_USER||{role:'guest'});
    railName(U && U.name ? U.name : 'Murat Özbey');
    injectUserHeader(U); hookExit();
    setDisplay('mExit', !!(U && U.logged));

    ensureItem('mTerminal', "<i class='fa-solid fa-terminal' style='color:#a78bfa'></i><span>Uçbirim</span>", function(){
      if (window.openTerminal) window.openTerminal();
      else dynScript('assets/ctx_extras.js', function(){ if(window.openTerminal) window.openTerminal(); });
    });

    if (U && U.logged) {
      removeItem('mUserCreate'); removeItem('mLogin');
      ensureItem('mProfile', "<i class='fa-regular fa-user' style='color:#60a5fa'></i><span>Profil</span>", function(){
        if (window.openProfileMini) window.openProfileMini();
        else dynScript('assets/profile.js', function(){ if(window.openProfileMini) window.openProfileMini(); });
      });
    } else {
      removeItem('mProfile');
      ensureItem('mUserCreate', "<i class='fa-regular fa-user' style='color:#22c55e'></i><span>Kullanıcı Oluştur</span>", function(){
        if (window.openRegisterMini) window.openRegisterMini(); else alert('Kayıt bileşeni yüklenemedi');
      });
      ensureItem('mLogin', "<i class='fa-solid fa-right-to-bracket' style='color:#a3e635'></i><span>Giriş Yap</span>", function(){
        if (window.openLoginMini) window.openLoginMini(); else dynScript('assets/login_mini.js', function(){ if(window.openLoginMini) window.openLoginMini(); });
      });
      railName('Murat Özbey');
    }
  });
})();