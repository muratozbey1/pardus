(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  var WALLS = (window.WALLPAPERS && Array.isArray(window.WALLPAPERS) && window.WALLPAPERS.length>0)
    ? window.WALLPAPERS.slice(0)
    : ["100.jpg","101.jpg","102.jpg","103.jpg","104.jpg","105.jpg","106.jpg","107.jpg","108.jpg"];
  function key(){
    var U = (window.SOFTDESK_USER||{});
    var u = (U.username||'guest'); return 'wall_idx_'+u;
  }
  function apply(i){
    i = ((i%WALLS.length)+WALLS.length)%WALLS.length;
    var file = WALLS[i];
    document.body.style.background = 'url(\"'+file+'\") center/cover fixed no-repeat, var(--bg)';
    try{ localStorage.setItem(key(), String(i)); }catch(e){}
    if (window._showToast) window._showToast('Duvar kağıdı: '+(i+1)+'/'+WALLS.length, 1500);
  }
  function init(){
    var i = 0;
    try{ var v = parseInt(localStorage.getItem(key())||'0',10); if(!isNaN(v)) i=v; }catch(e){}
    apply(i);
    window.wallpaperNext = function(){ i=(i+1)%WALLS.length; apply(i); };
    window.wallpaperApply = apply;
  }
  ready(init);
})();