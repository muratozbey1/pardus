/* Desktop trash bin: inject icon, drag-to-delete for folders/links + ctx delete */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function injectStyle(css){
    var s=document.createElement('style'); s.textContent=css; document.head.appendChild(s);
  }
  function toast(m){ if(window._showToast) window._showToast(m,1600); else alert(m); }

  injectStyle(`
  #trashBin{position:fixed; right:12px; bottom:calc(var(--panel-h,36px) + 12px); z-index:1200;}
  #trashBin .bin{width:46px;height:46px;border-radius:12px;border:1px solid var(--line);background:#0f1115aa;display:grid;place-items:center;backdrop-filter:blur(6px);cursor:grab}
  #trashBin .bin i{font-size:18px;color:#ef4444}
  #trashBin .bin.hot{outline:2px solid #ef4444}
  `);

  var binEl, hot=false, lastTarget=null;

  function ensureBin(){
    if (document.getElementById('trashBin')) return;
    var wrap = document.createElement('div'); wrap.id='trashBin';
    wrap.innerHTML = "<div class='bin' title='Çöp Kutusu'><i class='fa-solid fa-trash-can'></i></div>";
    document.body.appendChild(wrap);
    binEl = wrap.querySelector('.bin');
  }

  async function apiDelFolder(id, owner){
    const fd = new FormData(); fd.append('action','delete_folder'); fd.append('id', id); if(owner) fd.append('owner', owner);
    const r = await fetch('api.php', {method:'POST', body:fd, credentials:'same-origin'});
    const j = await r.json().catch(()=>({ok:false}));
    return j && j.ok;
  }
  async function apiDelLink(id, owner){
    const fd = new FormData(); fd.append('action','delete_link'); fd.append('id', id); if(owner) fd.append('owner', owner);
    const r = await fetch('api.php', {method:'POST', body:fd, credentials:'same-origin'});
    const j = await r.json().catch(()=>({ok:false}));
    return j && j.ok;
  }

  function overBin(x,y){
    if (!binEl) return false;
    const r = binEl.getBoundingClientRect();
    return x>=r.left && x<=r.right && y>=r.top && y<=r.bottom;
  }

  function setHot(v){ if (!binEl) return; hot=v; if (v) binEl.classList.add('hot'); else binEl.classList.remove('hot'); }

  function ctxDelete(target){
    if (!target) return;
    if (target.dataset && /^lnk-/.test(target.dataset.id||'')){
      const id = target.dataset.linkId;
      const owner = target.dataset.owner||'';
      apiDelLink(id, owner).then(ok=>{
        if(ok){ try{ target.remove(); }catch(e){} toast('Kısayol silindi'); if(window.loadFolders) window.loadFolders(); }
        else toast('Silinemedi');
      });
    } else if (target.dataset && /^f_/.test(target.dataset.id||'')){
      const id = target.dataset.id;
      const owner = target.dataset.owner||'';
      apiDelFolder(id, owner).then(ok=>{
        if(ok){ try{ target.remove(); }catch(e){} toast('Klasör silindi'); if(window.loadFolders) window.loadFolders(); }
        else toast('Silinemedi');
      });
    }
  }

  ready(function(){
    ensureBin();

    // Drag takibi: grid üzerinde pointerdown ile hedefi yakala
    document.addEventListener('pointerdown', function(e){
      const it = (e.target && e.target.closest) ? e.target.closest('.item') : null;
      if (it) { lastTarget = it; }
    }, true);

    document.addEventListener('pointermove', function(e){
      if (!lastTarget) return;
      setHot( overBin(e.clientX, e.clientY) );
    }, true);

    document.addEventListener('pointerup', function(e){
      if (!lastTarget) { setHot(false); return; }
      const drop = overBin(e.clientX, e.clientY);
      setHot(false);
      if (drop){
        // Sil
        ctxDelete(lastTarget);
      }
      lastTarget = null;
    }, true);

    // Sağ tık: seçime göre "Sil" ekle
    var menu = document.getElementById('ctxMenu');
    if (menu){
      var el = document.createElement('div'); el.className='citem'; el.id='ctxDelete'; el.innerHTML="<i class='fa-solid fa-trash' style='color:#ef4444'></i><span>Sil</span>";
      menu.appendChild(el);
      el.addEventListener('click', function(e){
        e.preventDefault(); e.stopPropagation();
        var tgt = window.__CTX_TARGET || null;
        if (!tgt){ toast('Öge seçilemedi'); return; }
        ctxDelete(tgt);
      });

      document.addEventListener('contextmenu', function(e){
        var it = (e.target && e.target.closest) ? e.target.closest('.item') : null;
        window.__CTX_TARGET = it;
        // Gizle/göster: sadece klasör/kısayolsa göster
        var show = !!(it && ( /^f_/.test(it.dataset.id||'') || /^lnk-/.test(it.dataset.id||'') ));
        el.style.display = show ? '' : 'none';
      }, true);
    }
  });
})();