/* loadFolders() override: do NOT inject owner for global items; dblclick open */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  const PAD=10, ICON_W=96, ICON_H=96;
  function eh(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;","\"":"&quot;","'":"&#39;"}[m]));}
  function iconHTML(spec){
    if(!spec) return "<i class='fa-regular fa-folder' style='color:#8ab4f8'></i>";
    if(spec.startsWith('fa:')){
      let cls=spec.substring(3), colr=null; const p=cls.indexOf("|");
      if(p>-1){ colr=cls.substring(p+1); cls=cls.substring(0,p); }
      return "<i class='"+cls+"'"+(colr?(" style='color:"+colr+"'"):"")+"></i>";
    }
    return "<i class='fa-regular fa-folder' style='color:#8ab4f8'></i>";
  }
  function place(el,key,col,row){
    try{ if (typeof window.place==='function') { window.place(el,key,col,row); return; } }catch(_){}
    const grid = document.getElementById('grid');
    if (!grid) return;
    const x = PAD + (col||0)*ICON_W, y = PAD + (row||0)*ICON_H;
    el.style.left = x+'px'; el.style.top = y+'px';
  }
  async function loadFoldersNew(){
    const grid = document.getElementById('grid'); if(!grid){ console.warn('[folders_patch] #grid yok'); return; }
    grid.innerHTML = "";
    const home=document.createElement("div"); home.className="item"; home.dataset.id="home";
    home.innerHTML="<div class='ficon'><i class='fa-solid fa-house'></i></div><div class='flabel'>Ev</div>";
    home.addEventListener("dblclick",()=>{ if(home._dragged) return; (window.openWindowEx||window.openWindow||function(){})({id:"home",title:"Ev",html:"<div style='padding:8px'>Ev klasörü.</div>",w:520,h:360}); });
    grid.appendChild(home);
    if (typeof window.dragify === 'function'){ try{ window.dragify(home,"home"); }catch(e){} }
    place(home,"home",0,0);

    const U = (window.SOFTDESK_USER||{});
    const EMAIL = U.email || '';

    try{
      const r = await fetch("api.php?action=list_folders", { cache:"no-store", credentials:"same-origin" });
      if (!r.ok){ console.error("[folders_patch] list_folders HTTP", r.status); return; }
      const j = await r.json();
      const list = (j && j.folders) ? j.folders : [];
      let col=0,row=1;
      list.forEach(f=>{
        try{
          const el=document.createElement("div"); el.className="item"; el.dataset.id=f.id;
          // SADECE server döndürdüyse owner ata; globalde boş bırak
          if (f.owner) el.dataset.owner = f.owner;
          const spec=f.icon||"fa:fa-regular fa-folder|#8ab4f8";
          el.innerHTML="<div class='ficon'>"+iconHTML(spec)+"</div><div class='flabel'>"+eh(f.name||"Klasör")+"</div>";
          el.addEventListener("dblclick",()=>{ if(el._dragged) return; (window.openWindowEx||window.openWindow||function(){})({id:"fld-"+f.id,title:f.name,html:"<div style='padding:8px'>"+eh(f.name)+" klasörü.</div>",w:560,h:400}); });
          grid.appendChild(el);
          if (typeof window.dragify === 'function'){ try{ window.dragify(el,"fld-"+f.id); }catch(e){} }
          place(el,"fld-"+f.id,col,row);
          row++; if((row+1)*ICON_H > grid.clientHeight-120){ row=0; col++; }
        }catch(itemErr){ console.error('[folders_patch] ikon oluşturma hatası', itemErr); }
      });
    }catch(err){
      console.error("[folders_patch] list_folders fetch hatası", err);
    }
  }
  ready(function(){
    window.loadFolders = loadFoldersNew;
    try{ loadFoldersNew(); }catch(e){}
  });
})();