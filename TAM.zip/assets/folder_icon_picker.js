/* Fill #icoGrid with richer Font Awesome choices (minimal UI) */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  ready(function(){
    var grid = document.getElementById('icoGrid');
    var hidden = document.getElementById('fldIcon');
    if(!grid || !hidden) return;

    var icons = [
      ["fa-regular fa-folder","#8ab4f8"],["fa-solid fa-folder","#fbbf24"],["fa-regular fa-folder-open","#60a5fa"],
      ["fa-solid fa-folder-tree","#f59e0b"],["fa-solid fa-folder-plus","#22c55e"],["fa-solid fa-folder-gear","#94a3b8"],
      ["fa-solid fa-image","#34d399"],["fa-regular fa-image","#34d399"],["fa-solid fa-file-lines","#f59e0b"],
      ["fa-regular fa-file-lines","#f59e0b"],["fa-solid fa-database","#c084fc"],["fa-solid fa-cloud","#60a5fa"],
      ["fa-solid fa-globe","#22c55e"],["fa-solid fa-code","#93c5fd"],["fa-solid fa-music","#ef4444"],
      ["fa-solid fa-video","#eab308"],["fa-solid fa-camera","#f472b6"],["fa-solid fa-book","#e879f9"],
      ["fa-solid fa-briefcase","#f97316"],["fa-solid fa-shield-halved","#f43f5e"],["fa-solid fa-chart-line","#22c55e"],
      ["fa-solid fa-gamepad","#22d3ee"],["fa-solid fa-microchip","#f472b6"],["fa-solid fa-bolt","#fde047"],
      ["fa-brands fa-github","#c084fc"],["fa-brands fa-chrome","#f59e0b"],["fa-brands fa-firefox","#f97316"],
      ["fa-solid fa-paperclip","#93c5fd"],["fa-solid fa-user","#a78bfa"],["fa-regular fa-circle-user","#a78bfa"]
    ];

    grid.innerHTML = "";
    icons.forEach(function(def, i){
      var cls = def[0], color = def[1];
      var b = document.createElement('button'); b.type='button'; b.className='ico';
      b.innerHTML = "<i class='"+cls+"' style='color:"+color+"'></i>";
      b.addEventListener('click', function(){
        Array.from(grid.querySelectorAll('.ico')).forEach(function(x){ x.classList.remove('sel'); });
        b.classList.add('sel');
        hidden.value = 'fa:'+cls+'|'+color;
      });
      if (i===0){ b.classList.add('sel'); hidden.value='fa:'+cls+'|'+color; }
      grid.appendChild(b);
    });
  });
})();