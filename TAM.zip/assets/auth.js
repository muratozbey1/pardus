(function(){
  const pe = document.getElementById('email');
  const pp = document.getElementById('password');
  const eye = document.getElementById('toggleEye');
  const ce = document.getElementById('copyEmail');
  const cp = document.getElementById('copyPass');
  if(pe) pe.value = pe.dataset.prefill||'';
  if(eye && pp){
    eye.addEventListener('click', ()=>{
      pp.type = pp.type==='password' ? 'text' : 'password';
    });
  }
  function copy(txt){ navigator.clipboard && navigator.clipboard.writeText(txt).catch(()=>{}); }
  if(ce && pe){ ce.addEventListener('click', ()=>copy(pe.dataset.prefill||'admin@local')); }
  if(cp){ cp.addEventListener('click', ()=>copy('Admin123!')); }
})();