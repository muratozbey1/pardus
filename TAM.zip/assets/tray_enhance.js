// Wi-Fi / Ses / Pil
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function $(s,c=document){ return c.querySelector(s); }
  ready(function(){
    const tray = $('.tray'); if(!tray) return;

    const net = tray.querySelector('.net');
    function updateWifi(){ if(!net) return; const online=navigator.onLine; const i=net.querySelector('i'); if(i) i.style.opacity=online?'1':'.6'; net.title = online?'Wi-Fi: bağlı':'Wi-Fi: bağlı değil'; }
    window.addEventListener('online',updateWifi); window.addEventListener('offline',updateWifi); updateWifi();

    let volWrap = tray.querySelector('.vol'); if(!volWrap){ volWrap=document.createElement('span'); volWrap.className='vol'; volWrap.innerHTML='<i class="fa-solid fa-volume-high"></i>'; const clock=$('.clock'); (clock&&clock.parentNode?clock.parentNode:tray).insertBefore(volWrap,clock||null); }
    let vol = parseInt(localStorage.getItem('pardus.vol')||'70',10); let muted = localStorage.getItem('pardus.muted')==='1';
    function upd(){ const i=volWrap.querySelector('i'); const v=Math.max(0,Math.min(100,vol|0)); const icon= (muted||v===0)?'fa-volume-xmark': v<35?'fa-volume-low': v<70?'fa-volume':'fa-volume-high'; if(i) i.className='fa-solid '+icon; volWrap.title = muted?'Ses: sessiz':('Ses: %'+v); }
    upd();
    volWrap.addEventListener('click',()=>{ muted=!muted; localStorage.setItem('pardus.muted',muted?'1':'0'); upd(); });
    volWrap.addEventListener('wheel',(e)=>{ e.preventDefault(); const d=Math.sign(e.deltaY)*-5; vol=Math.max(0,Math.min(100,vol+d)); if(vol>0&&muted) muted=false; localStorage.setItem('pardus.vol',String(vol)); upd(); },{passive:false});

    const bat = tray.querySelector('.bat');
    function setBat(level,chg){ if(!bat) return; const p=Math.round(level*100); const i=bat.querySelector('i'); if(i){ let cls='fa-battery-three-quarters'; if(p>=95) cls='fa-battery-full'; else if(p>=65) cls='fa-battery-three-quarters'; else if(p>=35) cls='fa-battery-half'; else if(p>=15) cls='fa-battery-quarter'; else cls='fa-battery-empty'; i.className='fa-solid '+cls; } bat.title='Pil: %'+p+(chg?' (şarj oluyor)':''); }
    if(bat && navigator.getBattery){ try{ navigator.getBattery().then(b=>{ setBat(b.level,b.charging); b.addEventListener('levelchange',()=>setBat(b.level,b.charging)); b.addEventListener('chargingchange',()=>setBat(b.level,b.charging)); }); }catch(_){ bat.title='Pil'; } }
  });
})();