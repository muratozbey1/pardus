/* assets/uploader.after.js — QUIET stub (vQ) */
/* Bu dosya, eski 'uploader core not present yet' spam loglarını tamamen susturmak için hazırlanmıştır. */
(function(){
  if (window.__PARDUS_UPLOADER_AFTER_QUIET__) return;
  window.__PARDUS_UPLOADER_AFTER_QUIET__ = true;

  // Sessiz kip bayrağı (diğer scriptler görürse log atmasın)
  try{ window.PardusUploaderAfterQuiet = true; }catch(_){}

  // İsteğe bağlı: Çekirdek hazırsa tek seferlik minimal bağlama yapılabilir (şu an gerek yok).
  // Bu stub bilerek hiçbir log yazmaz ve hiçbir loop çalıştırmaz.
  window.PardusUploaderAfter = { version: 'vQ', quiet: true };
})();