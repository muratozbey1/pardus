/* assets/upload_policy_client.js — apply accept attr + rule text */
(function(){
  if (window.__PARDUS_UPLOAD_POLICY_CLIENT__) return; window.__PARDUS_UPLOAD_POLICY_CLIENT__=true;
  async function getPolicy(){ try{ const r=await fetch('api_upload_config.php',{cache:'no-store',credentials:'same-origin'}); if(!r.ok) return null; const j=await r.json(); return j&&j.policy?j.policy:null; }catch(e){ return null; } }
  async function apply(area){
    const p = await getPolicy(); if(!p) return;
    let inp = area && area.querySelector ? area.querySelector('input[type="file"]') : null;
    if(!inp) inp=document.querySelector('input[type="file"]');
    if(inp && p.allowed_ext && p.allowed_ext.length) inp.setAttribute('accept', p.allowed_ext.map(e=>'.'+e).join(','));
    else if(inp && p.image_only) inp.setAttribute('accept', 'image/*');
    try{
      const host = area || document.querySelector('[data-upload-target]') || document.body;
      let info = host.querySelector('#upl-policy-info'); if(!info){ info=document.createElement('div'); info.id='upl-policy-info'; info.style.cssText='opacity:.7;font-size:12px;margin-top:6px'; host.appendChild(info); }
      let text=''; if(p.image_only) text+='Sadece görseller'; if(p.allowed_ext&&p.allowed_ext.length) text+=(text?' • ':'')+'İzinli: '+p.allowed_ext.join(', '); if(p.max_size_mb) text+=(text?' • ':'')+'Max: '+p.max_size_mb+'MB'; info.textContent=text;
    }catch(_){}
  }
  const mo=new MutationObserver((muts)=>{ muts.forEach(m=>{ m.addedNodes&&Array.from(m.addedNodes).forEach(n=>{ if(!(n instanceof HTMLElement)) return; const area=n.querySelector&&n.querySelector('[data-upload-target]'); if(area) apply(area); }); }); });
  mo.observe(document.documentElement,{childList:true,subtree:true}); apply(document.body);
})();