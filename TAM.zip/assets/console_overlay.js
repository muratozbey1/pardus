/* assets/console_overlay.js — v16: minimize, filter, export */
(function(){
  if (window.__PARDUS_CONSOLE_OVERLAY_V16__) return;
  window.__PARDUS_CONSOLE_OVERLAY_V16__ = true;

  const LS_KEY_POS = 'pc_pos';
  const LS_KEY_MIN = 'pc_min';
  const LS_KEY_FILT = 'pc_filter'; // 'all' | 'errors'

  const css = `
  @keyframes scanline { 0%{background-position:0 -20px} 100%{background-position:0 20px} }
  #pardusConsole {
    position: fixed; top: 12px; right: 12px; width: 560px; height: 300px;
    background: rgba(7,12,10,0.92);
    border: 1px solid #173b2f; border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,.55), inset 0 0 0 1px #0a2019;
    color: #c7ffcf; font: 12px/1.5 ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
    z-index: 2147483000; display: flex; flex-direction: column;
    backdrop-filter: blur(3px);
  }
  #pardusConsole.hidden { display:none; }
  #pardusConsole.min .body, #pardusConsole.min .ft { display:none; }
  #pardusConsole.min { height: auto; }
  #pardusConsole .hdr {
    cursor: move; user-select: none;
    padding: 8px 10px; display: flex; align-items: center; gap: 8px;
    border-bottom: 1px solid #173b2f;
    background: linear-gradient(180deg, rgba(10,25,20,.75), rgba(8,18,15,.75));
    position: relative;
  }
  #pardusConsole .hdr::after {
    content:""; position:absolute; inset:0;
    background: repeating-linear-gradient(0deg, rgba(48,255,129,.05), rgba(48,255,129,.0) 2px);
    mix-blend-mode: screen; pointer-events:none; animation: scanline 2.2s linear infinite;
  }
  #pardusConsole .title { color:#8fffb1; letter-spacing:.3px; font-weight:600 }
  #pardusConsole .spacer { flex:1 }
  #pardusConsole .btn {
    height: 26px; min-width: 26px; display:grid; place-items:center; padding:0 8px;
    background:#0a1a14; border:1px solid #1c3f32; color:#8fffb1; border-radius:8px; cursor:pointer;
    box-shadow: 0 0 0 1px #0a2019 inset;
  }
  #pardusConsole .btn:hover { filter: brightness(1.15) }
  #pardusConsole select {
    height: 26px; background:#0a1a14; color:#8fffb1; border:1px solid #1c3f32; border-radius:8px; padding:0 8px;
  }
  #pardusConsole .body { flex:1; overflow:auto; padding:8px 10px; }
  #pardusConsole .line { white-space: pre-wrap; word-break: break-word; margin:2px 0; }
  #pardusConsole .ts { opacity:.55; margin-right:6px }
  #pardusConsole .lvl-log { color:#a7ffb7 }
  #pardusConsole .lvl-info{ color:#8fffb1 }
  #pardusConsole .lvl-warn{ color:#ffe38f }
  #pardusConsole .lvl-error{ color:#ff8f8f }
  #pardusConsole .ft { display:flex; align-items:center; gap:8px; padding:6px 10px; border-top:1px solid #173b2f; }
  #pardusConsole .ft .count { opacity:.6 }
  `;
  const style = document.createElement('style'); style.textContent = css; document.head.appendChild(style);

  // Create panel
  const root = document.createElement('div');
  root.id = 'pardusConsole';
  root.innerHTML = `
    <div class="hdr" id="pcDrag">
      <div class="title">Pardus Konsol</div>
      <div class="spacer"></div>
      <label style="display:flex;align-items:center;gap:6px">
        <span style="opacity:.7">Filtre</span>
        <select id="pcFilter">
          <option value="all">Tümü</option>
          <option value="errors">Sadece Hatalar</option>
        </select>
      </label>
      <button class="btn" id="pcExport" title="Dışa Aktar">Dışa Aktar</button>
      <button class="btn" id="pcMin" title="Küçült">–</button>
      <button class="btn" id="pcClear" title="Temizle">Temizle</button>
      <button class="btn" id="pcClose" title="Kapat">✕</button>
    </div>
    <div class="body" id="pcBody"></div>
    <div class="ft"><span class="count" id="pcCount">0 satır</span><span style="margin-left:auto;opacity:.55">Ctrl+Alt+C: Göster/Gizle</span></div>
  `;
  document.body.appendChild(root);

  // Position & state restore
  try{
    const pos = JSON.parse(localStorage.getItem(LS_KEY_POS)||'null');
    if (pos && typeof pos.x==='number' && typeof pos.y==='number'){
      root.style.left = pos.x+'px';
      root.style.top = pos.y+'px';
      root.style.right = 'auto';
    }
  }catch(_){}
  try{
    const min = localStorage.getItem(LS_KEY_MIN);
    if (min === '1') root.classList.add('min');
    const filt = localStorage.getItem(LS_KEY_FILT);
    if (filt === 'errors') document.getElementById('pcFilter').value = 'errors';
  }catch(_){}

  // Dragging
  (function(){
    const drag = document.getElementById('pcDrag');
    let sx=0, sy=0, x=0, y=0, moving=false;
    drag.addEventListener('mousedown', (e)=>{
      // allow clicking buttons/selects
      if (e.target && (e.target.tagName==='BUTTON' || e.target.tagName==='SELECT' || e.target.tagName==='OPTION')) return;
      moving=true; sx=e.clientX; sy=e.clientY;
      const rect=root.getBoundingClientRect(); x=rect.left; y=rect.top;
      document.body.style.userSelect='none';
    });
    window.addEventListener('mousemove', (e)=>{
      if(!moving) return;
      const nx = x+(e.clientX-sx), ny = y+(e.clientY-sy);
      root.style.left = Math.max(6, Math.min(window.innerWidth-200, nx))+'px';
      root.style.top  = Math.max(6, Math.min(window.innerHeight-80, ny))+'px';
      root.style.right='auto';
    });
    window.addEventListener('mouseup', ()=>{
      if(!moving) return; moving=false; document.body.style.userSelect='';
      const rect=root.getBoundingClientRect();
      try{ localStorage.setItem(LS_KEY_POS, JSON.stringify({x:rect.left,y:rect.top})); }catch(_){}
    });
  })();

  // Buttons
  const bodyEl = document.getElementById('pcBody');
  const filterSel = document.getElementById('pcFilter');
  document.getElementById('pcClose').onclick = ()=>{ root.classList.add('hidden'); };
  document.getElementById('pcMin').onclick = ()=>{
    root.classList.toggle('min');
    try{ localStorage.setItem(LS_KEY_MIN, root.classList.contains('min') ? '1':'0'); }catch(_){}
  };
  document.getElementById('pcClear').onclick = ()=>{ logs.length=0; renderAll(); };
  document.getElementById('pcExport').onclick = ()=>{
    try{
      const lines = logs.map(l => `[${l.time}] ${l.level.toUpperCase()} ${l.text}`).join('\n');
      const blob = new Blob([lines], {type:'text/plain'});
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'pardus-console-logs.txt';
      document.body.appendChild(a);
      a.click();
      setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 0);
    }catch(e){ alert('Dışa aktarılamadı'); }
  };
  filterSel.onchange = ()=>{
    try{ localStorage.setItem(LS_KEY_FILT, filterSel.value); }catch(_){}
    renderAll();
  };

  // Hotkey
  document.addEventListener('keydown', (e)=>{
    if(e.ctrlKey && e.altKey && (e.key==='c' || e.key==='C')){
      root.classList.toggle('hidden');
    }
  });

  // Log store
  const logs = []; // {level:'log'|'info'|'warn'|'error', time:string, text:string}
  let count = 0, maxLines = 1000;
  function updateCount(v){ document.getElementById('pcCount').textContent = v+' satır'; }
  function ts(){ const d=new Date(); return d.toLocaleTimeString?.() || d.toTimeString(); }
  function passFilter(level){
    const f = filterSel.value;
    return (f==='all') ? true : (level==='error');
  }
  function makeNode(rec){
    const line = document.createElement('div');
    line.className = 'line lvl-'+rec.level;
    const time = document.createElement('span'); time.className='ts'; time.textContent='['+rec.time+']';
    const msg = document.createElement('span'); msg.textContent = rec.text;
    line.append(time, msg);
    return line;
  }
  function renderAll(){
    bodyEl.innerHTML='';
    let shown = 0;
    for (const r of logs){
      if (!passFilter(r.level)) continue;
      bodyEl.appendChild(makeNode(r));
      shown++;
    }
    count = shown; updateCount(count);
    bodyEl.scrollTop = bodyEl.scrollHeight;
  }
  function push(level, args){
    const text = Array.from(args).map(v=>{
      if (v instanceof Error) return v.stack || v.message;
      if (typeof v === 'object') { try{ return JSON.stringify(v); }catch(_){ return String(v); } }
      return String(v);
    }).join(' ');
    const rec = { level, time: ts(), text };
    logs.push(rec);
    if (logs.length > maxLines) logs.shift();
    if (passFilter(level)){
      bodyEl.appendChild(makeNode(rec));
      count++; updateCount(count);
      bodyEl.scrollTop = bodyEl.scrollHeight;
    }
  }

  // Proxy console
  const org = { log:console.log, info:console.info, warn:console.warn, error:console.error };
  console.log = function(){ try{ push('log', arguments);}catch(_){ } return org.log.apply(console, arguments); };
  console.info= function(){ try{ push('info',arguments);}catch(_){ } return org.info.apply(console, arguments); };
  console.warn= function(){ try{ push('warn',arguments);}catch(_){ } return org.warn.apply(console, arguments); };
  console.error=function(){ try{ push('error',arguments);}catch(_){ } return org.error.apply(console, arguments); };

  // Expose simple API
  window.PardusConsole = {
    show(){ root.classList.remove('hidden'); },
    hide(){ root.classList.add('hidden'); },
    clear(){ logs.length=0; renderAll(); },
    element: root,
    setFilter(mode){ filterSel.value = (mode==='errors'?'errors':'all'); renderAll(); }
  };

  // Initial render (in case any logs emitted before)
  renderAll();
})();