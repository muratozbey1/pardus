/* assets/menu_upload_admin.js — Start menüye 'Upload Ayarları' kısa yolu */
(function(){
  if (window.__PARDUS_MENU_UPLOAD_ADMIN__) return; window.__PARDUS_MENU_UPLOAD_ADMIN__=true;
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function add(){
    const bar = document.querySelector('.start-menu, #start, #menu, .topbar, .toolbar');
    if (!bar) return;
    const btn = document.createElement('button');
    btn.textContent = '⚙️ Upload Ayarları';
    btn.style.cssText='margin-left:8px;padding:6px 10px;border-radius:8px;border:1px solid #1c3f32;background:#0a1a14;color:#8fffb1;cursor:pointer';
    btn.onclick = ()=>{ window.open('admin_upload_settings.php','_blank'); };
    bar.appendChild(btn);
  }
  ready(add);
})();