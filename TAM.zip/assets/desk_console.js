/* desk_console.js v2.0 — Sağ kenarda hep açık mini konsol
   - fetch & XHR intercept (istek/yanıt)
   - olay kaydı: ziyaret, login/register/çöp vb. heuristic
   - butonlar: Pause, Clear, Copy, Save, Auto-scroll
   - localStorage ile açık/kapalı ve pause durumu
   - tema: koyu, mevcut değişkenlerle uyumlu
*/
(function(){
  if (window.__DESK_CONSOLE_2__) return; window.__DESK_CONSOLE_2__ = true;
  const LS = {
    OPEN: 'desklog_open',
    PAUSE: 'desklog_pause',
    AUTOSCROLL: 'desklog_autoscroll'
  };
  const C = {
    maxBody: 1200, // yanıt/kontenjan kısaltma
    panelW: 360
  };

  // === UI ===
  const css = `
  .desklog{position:fixed;top:0;right:0;height:100%;width:${C.panelW}px;z-index:20000;
    background:var(--bg2,#1b1f28);border-left:1px solid var(--line,#2a2f3b);box-shadow:var(--shadow,0 14px 34px rgba(0,0,0,.45));
    display:flex;flex-direction:column;font:12px/1.4 Inter,system-ui,Arial,sans-serif;color:#e6e9ee}
  .desklog .hd{display:flex;align-items:center;gap:8px;padding:8px;border-bottom:1px solid var(--line,#2a2f3b);background:linear-gradient(#202532,#181d26)}
  .desklog .hd .t{font-weight:700;flex:1}
  .desklog .hd .btn{background:#22293a;border:1px solid #2a2f3b;border-radius:8px;color:#e6e9ee;padding:6px 8px;cursor:pointer}
  .desklog .hd .btn.act{outline:2px solid #3b82f6}
  .desklog .bd{flex:1;overflow:auto;padding:8px}
  .desklog .ft{padding:6px 8px;border-top:1px solid var(--line,#2a2f3b);display:flex;align-items:center;gap:10px}
  .desklog .line{display:grid;grid-template-columns:44px 1fr;gap:8px;padding:6px 8px;background:#0f1115;border:1px solid #232732;border-radius:8px;margin-bottom:6px}
  .desklog .tag{opacity:.85}
  .desklog .dir{opacity:.9}
  .desklog .time{opacity:.6}
  .desklog .msg{white-space:pre-wrap;word-break:break-word}
  .desklog .kv{opacity:.85}
  .desklog .pill{display:inline-block;padding:1px 6px;border:1px solid #2a2f3b;border-radius:999px;margin-left:6px;opacity:.85}
  .desklog .ok{color:#22c55e}.desklog .err{color:#ef4444}
  .desklog .warn{color:#fbbf24}
  .desklog .mut{opacity:.6}
  .desklog .copyok{opacity:.8;margin-left:auto}
  .desklog .dragbar{position:absolute;left:-6px;top:0;width:6px;height:100%;cursor:ew-resize;opacity:0}
  `;
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  // util
  const z = (n)=>String(n).padStart(2,'0');
  function now(){
    const d = new Date();
    return `[${z(d.getHours())}:${z(d.getMinutes())}:${z(d.getSeconds())}]`;
  }
  function esc(s){ return String(s||'').replace(/[&<>"]/g, m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[m])); }
  function clamp(s, n=C.maxBody){ s = String(s||''); return s.length>n ? (s.slice(0,n)+' …('+ (s.length-n) +'B)') : s; }

  // panel
  const panel = document.createElement('div');
  panel.className = 'desklog';
  panel.innerHTML = `
    <div class="dragbar"></div>
    <div class="hd">
      <div class="t">Konsol (Log)<span class="pill mut">Auto-scroll</span></div>
      <button class="btn" id="dlPause">Pause</button>
      <button class="btn" id="dlClear">Clear</button>
      <button class="btn" id="dlCopy">Copy</button>
      <button class="btn" id="dlSave">Save</button>
    </div>
    <div class="bd" id="dlBody"></div>
    <div class="ft mut">Kısayol: Ctrl+~</div>`;
  document.body.appendChild(panel);
  const bd = panel.querySelector('#dlBody');
  const bPause = panel.querySelector('#dlPause');
  const bClear = panel.querySelector('#dlClear');
  const bCopy  = panel.querySelector('#dlCopy');
  const bSave  = panel.querySelector('#dlSave');
  const pill   = panel.querySelector('.pill');

  // drag resize
  (function(){
    const bar = panel.querySelector('.dragbar');
    let down=false, sx=0, sw=0;
    bar.addEventListener('mousedown', (e)=>{ down=true; sx=e.clientX; sw=panel.offsetWidth; document.body.style.userSelect='none'; });
    document.addEventListener('mousemove',(e)=>{
      if(!down) return;
      const dx = sx - e.clientX;
      const w = Math.min(Math.max(sw+dx, 240), Math.min(720, window.innerWidth*0.8));
      panel.style.width = w+'px';
    });
    document.addEventListener('mouseup',()=>{ down=false; document.body.style.userSelect=''; });
  })();

  // state
  let paused = (localStorage.getItem(LS.PAUSE)==='1');
  let autoscroll = (localStorage.getItem(LS.AUTOSCROLL)!=='0'); // default true
  function setPause(v){ paused=!!v; localStorage.setItem(LS.PAUSE, v?'1':'0'); bPause.classList.toggle('act', paused); }
  function setAuto(v){ autoscroll=!!v; localStorage.setItem(LS.AUTOSCROLL, v?'1':'0'); pill.classList.toggle('act', autoscroll); }
  // fix typo in setPause key string below

  // log buffer
  const buf = [];
  function pushLine(html){
    if (paused) return;
    const div = document.createElement('div');
    div.className='line';
    div.innerHTML = html;
    bd.appendChild(div);
    if (autoscroll) bd.scrollTop = bd.scrollHeight;
    buf.push(div.innerText);
    if (buf.length>5000) buf.shift();
  }

  // controls
  bPause.addEventListener('click', ()=> setPause(!paused));
  bClear.addEventListener('click', ()=> { bd.innerHTML=''; buf.length=0; });
  bCopy.addEventListener('click', async ()=>{
    try{
      await navigator.clipboard.writeText(buf.join('\n'));
      const ok = document.createElement('span'); ok.className='copyok mut'; ok.textContent='kopyalandı';
      panel.querySelector('.hd').appendChild(ok); setTimeout(()=>ok.remove(),1200);
    }catch(e){ alert('Kopyalanamadı'); }
  });
  bSave.addEventListener('click', ()=>{
    const blob = new Blob([buf.join('\n')], {type:'text/plain'});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = 'desklog_'+Date.now()+'.txt'; a.click();
    setTimeout(()=>URL.revokeObjectURL(a.href), 2000);
  });
  pill.addEventListener('click', ()=> setAuto(!autoscroll));
  setPause(paused); setAuto(autoscroll);

  // keyboard toggle (Ctrl+~)
  document.addEventListener('keydown',(e)=>{
    if (e.ctrlKey && (e.key==='`' || e.code==='Backquote')){
      panel.style.display = (panel.style.display==='none'?'':'none');
    }
  });

  // format helpers
  function block(tag, dir, msg, extra){
    const t = now();
    const d = dir==='in' ? '←' : '→';
    const tagHtml = `<div class="tag">${esc(tag)}<div class="time mut">${esc(t)}</div></div>`;
    const body = `<div class="msg">${msg}${extra?'<div class="kv mut">'+extra+'</div>':''}</div>`;
    return tagHtml + body;
  }

  function tryJson(s){
    try{ return JSON.stringify(JSON.parse(s), null, 2); }catch(_){ return null; }
  }

  // === Intercepts ===
  // fetch
  const _fetch = window.fetch;
  window.fetch = async function(input, init){
    try{
      const m = (init && init.method) || 'GET';
      const url = (typeof input==='string'? input : (input && input.url) || '');
      let body = (init && init.body) || '';
      if (body && typeof body!=='string' && body instanceof FormData){
        const kv=[]; body.forEach((v,k)=>kv.push(`${k}=${v}`)); body = kv.join('&');
      }
      const tag = (url.indexOf('api_trash.php')>-1?'TRASH': (url.indexOf('auth')>-1?'AUTH': (url.indexOf('api.php')>-1?'API':'HTTP')));
      pushLine(block(tag,'out', esc(`${m} ${url}`), esc(clamp(body||''))));
      const res = await _fetch.apply(this, arguments);
      const clone = res.clone();
      let text=''; try{ text = await clone.text(); }catch(_){}
      const pretty = tryJson(text);
      pushLine(block(tag,'in', esc(`${res.status} ${m} ${url}`), esc(clamp(pretty||text||''))));
      return res;
    }catch(e){
      pushLine(block('HTTP','in', `<span class="err">fetch hata:</span> ${esc(e.message||e)}`));
      throw e;
    }
  };

  // XHR
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url){
    this.__desklog = {method, url};
    return _open.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function(body){
    const info = this.__desklog || {method:'GET', url:'(xhr)'};
    const tag = (info.url.indexOf('auth')>-1?'AUTH':'XHR');
    pushLine(block(tag,'out', esc(`${info.method} ${info.url}`), esc(clamp(body||''))));
    this.addEventListener('loadend', ()=>{
      try{
        const txt = this.responseText || '';
        const pretty = tryJson(txt);
        pushLine(block(tag,'in', esc(`${this.status} ${info.method} ${info.url}`), esc(clamp(pretty||txt||''))));
      }catch(_){/*noop*/}
    });
    return _send.apply(this, arguments);
  };

  // === App-level events to log ===
  function logEvent(tag, msg){ pushLine(block(tag,'in', esc(msg))); }

  // visit
  logEvent('APP', 'visit: '+location.pathname+location.search);
  if (window.SOFTDESK_USER){
    logEvent('USER', (window.SOFTDESK_USER.logged?'logged-in: ':'guest: ') + (window.SOFTDESK_USER.email||'(no email)'));
  } else {
    logEvent('USER', 'state pending…');
    window.addEventListener('softdesk:state', ()=>{
      if (window.SOFTDESK_USER) logEvent('USER', (window.SOFTDESK_USER.logged?'logged-in: ':'guest: ') + (window.SOFTDESK_USER.email||'(no email)'));
    });
  }

  // bus helpers
  window.DeskLog = {
    log: (tag, msg)=>logEvent(tag,msg),
    line: (html)=>pushLine(html),
  };

  // listen app custom events if any
  window.addEventListener('softdesk:refresh', (e)=>{
    logEvent('APP', 'refresh requested: '+(e && e.detail && e.detail.source || 'unknown'));
  });
  window.addEventListener('softdesk:toast', (e)=>{
    logEvent('TOAST', (e && e.detail && e.detail.text)||'(empty)');
  });
  window.addEventListener('softdesk:state', (e)=>{
    logEvent('STATE', 'updated');
  });

  // error hooks
  window.addEventListener('error', (e)=>{
    pushLine(block('JS','in', `<span class="err">error:</span> ${esc(e.message)} @ ${esc(e.filename)}:${e.lineno}`));
  });
  window.addEventListener('unhandledrejection', (e)=>{
    pushLine(block('JS','in', `<span class="warn">unhandled:</span> ${esc((e.reason && (e.reason.message||e.reason)) || '')}`));
  });

  // default open
  panel.style.display = ''; // visible by default
})();