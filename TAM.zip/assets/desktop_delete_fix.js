/* assets/desktop_delete_fix.js — remove folder icon after delete & provide hard-delete fallback */
(function(){
  if (window.__PARDUS_DESK_DELETE_FIX__) return; window.__PARDUS_DESK_DELETE_FIX__=true;

  // Remember last context-menu target item
  document.addEventListener('contextmenu', function(ev){
    const it = ev.target && ev.target.closest && ev.target.closest('.item');
    if (it) window.__desk_last_target = it;
  }, true);

  // Hook XHR to api.php: if body contains 'delete' and response ok:true => remove icon
  (function(){
    const _open = XMLHttpRequest.prototype.open;
    const _send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url){ this.__url = String(url||''); return _open.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function(body){
      const self=this, prev=this.onreadystatechange;
      let isDel=false;
      try{
        // detect delete intent
        const s = (body instanceof FormData) ? Array.from(body.entries()).map(([k,v])=>k+'='+v).join('&') : String(body||'');
        if (/action=.*delete/i.test(s) || /delete_folder/i.test(s)) isDel = true;
      }catch(_) {}
      this.onreadystatechange = function(){
        if (prev) try{ prev.apply(self, arguments);}catch(_){}
        if (self.readyState===4 && self.status>=200 && self.status<300 && isDel && /api\.php\b/.test(self.__url||'')){
          try{
            const it = window.__desk_last_target || document.querySelector('.item.selected');
            if (it) it.remove();
          }catch(_){}
        }
      };
      return _send.apply(this, arguments);
    };
  })();

  // Add a fallback "Klasörü Sil (Hard)" into context menus to call our own API if lazım
  const mo = new MutationObserver((muts)=>{
    muts.forEach(m=>{
      m.addedNodes && Array.from(m.addedNodes).forEach(n=>{
        if (!(n instanceof HTMLElement)) return;
        const isMenu = /ctx|context|menu/i.test(n.className||'') || n.getAttribute('role')==='menu';
        if (isMenu){
          const btn = document.createElement('div');
          btn.textContent = '🗑 Klasörü Sil (Hard)';
          btn.style.cssText='padding:8px 10px;cursor:pointer;border-top:1px solid rgba(255,255,255,.06)';
          btn.onclick = async function(e){
            e.stopPropagation();
            const item = window.__desk_last_target || document.querySelector('.item.selected');
            if (!item){ n.remove(); return; }
            const label = item.querySelector('.flabel'); const name = label? label.textContent.trim() : '';
            if (!name){ n.remove(); return; }
            if (!confirm('"'+name+'" klasörü ve içeriği silinsin mi?')){ n.remove(); return; }
            try{
              const fd=new FormData(); fd.append('action','delete_folder'); fd.append('folder', name);
              const r = await fetch('api_files.php', {method:'POST', body:fd, credentials:'same-origin'});
              const j = await r.json(); if (j && j.ok){ item.remove(); }
            }catch(_){}
            n.remove();
          };
          n.appendChild(btn);
        }
      });
    });
  });
  mo.observe(document.documentElement, {childList:true, subtree:true});
})();