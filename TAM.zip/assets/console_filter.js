/* assets/console_filter.js — drop noisy shim logs from browser + overlay */
(function(){
  if (window.__PARDUS_CONSOLE_FILTER__) return; window.__PARDUS_CONSOLE_FILTER__=true;
  const patterns = [
    /konsol\s*\(log\)/i,
    /\[PardusUploader\/after\]/i,
    /uploader core not present yet/i,
    /gave up \(no target rendered\)/i
  ];
  function shouldDrop(args){
    try{
      for (const a of args){
        const s = (typeof a==='string') ? a : (a && a.message) ? a.message : (a && a.toString) ? String(a) : '';
        if (!s) continue;
        for (const p of patterns){ if (p.test(s)) return true; }
      }
    }catch(_){}
    return false;
  }
  const O = { log:console.log, info:console.info, warn:console.warn, error:console.error };
  ['log','info','warn','error'].forEach(fn=>{
    const orig = O[fn];
    console[fn] = function(){ if (shouldDrop(arguments)) return; return orig.apply(console, arguments); };
  });
  // Optional: hint to uploader shim to not auto-scan
  try{ window.PardusUploaderAuto = 'manual'; }catch(_){}
})();