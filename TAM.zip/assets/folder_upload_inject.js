/* assets/folder_upload_inject.js — v17
   - Drop alanı küçültüldü (90px)
   - Üstteki "Dosya Seç" butonu kaldırıldı
   - Sağda sadece ikonlu "Yenile" (🔄)
   - Drop alanı içinde RENKLİ "+ Dosya Yükle" butonu (id: pardus-upload-btn)
   - Dosya arama kutusu (canlı filtreleme)
   - Toplu silme (seçim + '🗑 Seçileni Sil')
*/
(function(){
  if (window.__PARDUS_FOLDER_UPLOAD_INJECT_V17__) return;
  window.__PARDUS_FOLDER_UPLOAD_INJECT_V17__ = true;

  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function safeKey(s){ return String(s||'').replace(/[^a-z0-9._-]+/gi,'_'); }
  function isImg(n){ return /\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(n||''); }

  // ---- Selection store (folder -> Set(fileNames))
  const __sel = new Map();
  function getSel(folder){ const k=safeKey(folder); if(!__sel.has(k)) __sel.set(k, new Set()); return __sel.get(k); }

  // ---- API helpers
  async function listFiles(folder){
    const url = 'api_files.php?action=list&folder='+encodeURIComponent(folder)+'&_='+(Date.now());
    const r = await fetch(url, {cache:'no-store', credentials:'same-origin'});
    if(!r.ok) return [];
    try{ const j = await r.json(); return Array.isArray(j.files)? j.files : []; }catch(_){ return []; }
  }
  async function delFile(folder, name){
    const fd = new FormData(); fd.append('action','delete'); fd.append('folder', folder); fd.append('name', name);
    const r = await fetch('api_files.php', {method:'POST', body:fd, credentials:'same-origin'});
    const j = await r.json().catch(()=>({ok:false}));
    return !!j.ok;
  }
  async function renFile(folder, name, to){
    const fd = new FormData(); fd.append('action','rename'); fd.append('folder', folder); fd.append('name', name); fd.append('to', to);
    const r = await fetch('api_files.php', {method:'POST', body:fd, credentials:'same-origin'});
    const j = await r.json().catch(()=>({ok:false}));
    return j;
  }

  // ---- Render files (with search + selection)
  async function renderFiles(containerSel, folder){
    const mount = document.querySelector(containerSel); if(!mount) return;
    const files = await listFiles(folder);
    const sel = getSel(folder);

    const grid = document.createElement('div');
    grid.className = 'fv-grid';
    grid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;';

    files.forEach(f=>{
      const card = document.createElement('div');
      card.className = 'fv-card';
      card.dataset.name = f.name;
      card.style.cssText = 'position:relative;border:1px solid #2a2f38;border-radius:10px;overflow:hidden;background:#0d1118;';

      // header: select checkbox
      const head = document.createElement('div');
      head.style.cssText = 'position:absolute;top:6px;left:6px;display:flex;gap:6px;z-index:2';
      const chk = document.createElement('input'); chk.type='checkbox'; chk.title='Seç'; chk.style.cssText='width:18px;height:18px;accent-color:#22d3ee;cursor:pointer';
      chk.checked = sel.has(f.name);
      chk.onchange = ()=>{ if(chk.checked) sel.add(f.name); else sel.delete(f.name); updateBulkBar(folder); };
      head.appendChild(chk);

      // actions right (rename/delete)
      const acts = document.createElement('div');
      acts.style.cssText = 'position:absolute;top:6px;right:6px;display:flex;gap:6px;z-index:2';
      const bRen = document.createElement('button'); bRen.innerHTML='✏️'; bRen.title='Yeniden Adlandır'; bRen.style.cssText='width:28px;height:28px;border:1px solid #2a2f38;border-radius:8px;background:#151b27;color:#e6e9ee;cursor:pointer';
      const bDel = document.createElement('button'); bDel.innerHTML='🗑'; bDel.title='Sil'; bDel.style.cssText='width:28px;height:28px;border:1px solid #2a2f38;border-radius:8px;background:#151b27;color:#e6e9ee;cursor:pointer';
      acts.append(bRen, bDel);

      // body preview
      const body = document.createElement('div'); body.style.cssText='height:120px;display:grid;place-items:center;overflow:hidden';
      if (isImg(f.name)){
        const img = document.createElement('img'); img.src = f.url+'?v='+(Date.now()); img.alt=f.name; img.style.cssText='max-width:100%;max-height:114px;display:block';
        body.appendChild(img);
      } else {
        const ic = document.createElement('div'); ic.textContent = (f.name.split('.').pop()||'FILE').toUpperCase(); ic.style.cssText='font:700 20px/1.2 system-ui;color:#8ab4f8';
        body.appendChild(ic);
      }

      // footer filename
      const foot = document.createElement('div');
      foot.textContent = f.name;
      foot.title = f.name;
      foot.style.cssText = 'padding:6px 8px;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#e6e9ee';

      // events
      bDel.onclick = async (ev)=>{ ev.stopPropagation(); if(!confirm('Silinsin mi?\n'+f.name)) return;
        const ok = await delFile(folder, f.name); if(ok){ sel.delete(f.name); renderFiles(containerSel, folder);} else { alert('Silinemedi'); } };
      bRen.onclick = async (ev)=>{ ev.stopPropagation(); const nn = prompt('Yeni ad:', f.name); if(!nn || nn===f.name) return;
        const res = await renFile(folder, f.name, nn); if(res && res.ok){ sel.delete(f.name); renderFiles(containerSel, folder);} else { alert('Yeniden adlandırılamadı'); } };

      card.onclick = ()=> window.open(f.url, '_blank');
      card.append(head, acts, body, foot);
      grid.appendChild(card);
    });

    mount.innerHTML = '';
    mount.appendChild(grid);

    // binding: search filter
    const search = document.getElementById('fv-search-'+safeKey(folder));
    if (search){
      const doFilter = ()=>{
        const q = search.value.trim().toLowerCase();
        grid.querySelectorAll('.fv-card').forEach(card=>{
          const name = (card.dataset.name||'').toLowerCase();
          card.style.display = (q==='' || name.includes(q)) ? '' : 'none';
        });
      };
      search.oninput = doFilter; doFilter();
    }

    updateBulkBar(folder);
  }

  // ---- Bulk bar update (counts + enable/disable)
  function updateBulkBar(folder){
    const sel = getSel(folder);
    const count = sel.size;
    const info = document.getElementById('fv-selected-info');
    const delBtn = document.getElementById('fv-delete-selected');
    const selAll = document.getElementById('fv-select-all');
    if (info) info.textContent = count>0 ? (count+' seçili') : 'Seçim yok';
    if (delBtn) delBtn.disabled = (count===0);
    if (selAll){
      // if everything visible selected -> checked, else indeterminate
      const container = document.querySelector('#'+('fv-list-'+safeKey(folder)));
      if (container){
        const cards = Array.from(container.querySelectorAll('.fv-card')).filter(c=>c.style.display!== 'none');
        const visNames = cards.map(c=>c.dataset.name);
        const allSelected = visNames.length>0 && visNames.every(n=> sel.has(n));
        const noneSelected = visNames.every(n=> !sel.has(n));
        selAll.checked = allSelected;
        selAll.indeterminate = (!allSelected && !noneSelected);
      }
    }
  }

  // ---- Refresh helper (public)
  window.refreshFileList = function(folder){
    if (!folder) return;
    const key = safeKey(folder);
    renderFiles('#fv-list-'+key, folder);
  };

  // ---- Attach window open with new UI
  function attach(){
    const grid = document.getElementById('grid'); if(!grid) return;
    if (grid.__upl_hooked_v17) return; grid.__upl_hooked_v17 = true;

    grid.addEventListener('dblclick', function(e){
      const el = e.target.closest('.item'); if(!el) return;
      const id = (el.dataset.id||''); if(!/^f_/.test(id)) return;
      e.preventDefault(); e.stopPropagation();
      const label = el.querySelector('.flabel'); const name = (label && label.textContent) ? label.textContent.trim() : id;
      const key = safeKey(name);
      const areaId = 'drop_'+key;
      const listId = 'fv-list-'+key;
      window.__upl_lastTarget = name;

      const html = ""
       + "<style>"
       + ".fv-toolbar{display:flex;align-items:center;gap:10px;padding:8px;border-bottom:1px solid #2a2f38}"
       + ".fv-toolbar .sp{flex:1}"
       + ".fv-iconbtn{width:30px;height:30px;display:grid;place-items:center;border:1px solid #2a2f38;border-radius:8px;background:#151b27;color:#e6e9ee;cursor:pointer}"
       + ".fv-drop{height:90px;padding:8px;border:1px dashed #2a2f38;border-radius:8px;margin:10px;display:grid;place-items:center;text-align:center}"
       + ".fv-upload{display:inline-block;padding:8px 14px;border-radius:10px;border:1px solid #0e766e;background:linear-gradient(180deg,#22d3ee,#14b8a6);color:#001a17;font-weight:700;cursor:pointer;box-shadow:0 2px 0 rgba(0,0,0,.2)}"
       + ".fv-bulk{display:flex;align-items:center;gap:10px;padding:6px 10px;border-top:1px solid #2a2f38;background:#0b1118;position:sticky;bottom:0}"
       + "</style>"
       + "<div class='fv-toolbar'>"
       +   "<input id='fv-search-"+key+"' type='search' placeholder='Ara...' style='width:240px;height:30px;background:#0a1a14;color:#8fffb1;border:1px solid #1c3f32;border-radius:8px;padding:0 10px'/>"
       +   "<div class='sp'></div>"
       +   "<button id='fv-refresh' class='fv-iconbtn' title='Yenile'>🔄</button>"
       + "</div>"
       + "<div id='"+areaId+"' data-upload-target='"+key+"' class='fv-drop'>"
       +   "<div style='opacity:.75;margin-bottom:8px'>Dosyaları buraya bırakın</div>"
       +   "<button id='pardus-upload-btn' class='fv-upload'>+ Dosya Yükle</button>"
       + "</div>"
       + "<div id='"+listId+"' style='min-height:220px;padding:10px;overflow:auto'></div>"
       + "<div class='fv-bulk'>"
       +   "<label style='display:flex;align-items:center;gap:6px'><input id='fv-select-all' type='checkbox' style='width:18px;height:18px;accent-color:#22d3ee'><span>Tümünü seç</span></label>"
       +   "<div id='fv-selected-info' style='opacity:.7'>Seçim yok</div>"
       +   "<div class='sp'></div>"
       +   "<button id='fv-delete-selected' class='fv-iconbtn' title='Seçileni Sil' disabled>🗑</button>"
       + "</div>";

      if (typeof window.openWindowEx === 'function') {
        window.openWindowEx({ id:'win_'+id, title:name, html:html, w:920, h:640 });
      } else if (typeof window.openWindow === 'function') {
        window.openWindow(name, html, 920, 640);
      }

      setTimeout(function(){
        try{ if (window.PardusUploadBindView) window.PardusUploadBindView('#'+areaId, name); }catch(_){}
        window.refreshFileList(name);

        // events
        const btnR = document.getElementById('fv-refresh'); if (btnR) btnR.onclick = ()=> window.refreshFileList(name);
        const delSel = document.getElementById('fv-delete-selected');
        const selAll = document.getElementById('fv-select-all');
        if (selAll){
          selAll.onchange = ()=>{
            const container = document.querySelector('#'+listId);
            const cards = Array.from(container.querySelectorAll('.fv-card')).filter(c=>c.style.display!== 'none');
            const sel = getSel(name);
            if (selAll.checked){
              cards.forEach(c=> sel.add(c.dataset.name));
            } else {
              cards.forEach(c=> sel.delete(c.dataset.name));
            }
            // check checkboxes
            cards.forEach(c=>{ const box=c.querySelector('input[type="checkbox"]'); if(box) box.checked = sel.has(c.dataset.name); });
            updateBulkBar(name);
          };
        }
        if (delSel){
          delSel.onclick = async ()=>{
            const sel = getSel(name); const arr = Array.from(sel);
            if (arr.length===0) return;
            if (!confirm(arr.length+' dosya silinsin mi?')) return;
            delSel.disabled = true;
            for (const nm of arr){
              try{ await delFile(name, nm); }catch(_){}
            }
            getSel(name).clear();
            window.refreshFileList(name);
          };
        }
      },0);
    }, true);
  }

  function install(){
    window.PardusUploaderConfig = Object.assign({ api:'api_upload.php', mountButton:true, afterUploadRefresh:true }, window.PardusUploaderConfig||{});
    function load(url, cb){ const s=document.createElement('script'); s.src=url; s.onload=cb; document.body.appendChild(s); }
    function ensureUploader(cb){ if (window.PardusUploadBindView){ cb(); return; } load('assets/uploader.js', ()=> load('assets/uploader.after.js', cb)); }
    ensureUploader(()=>{
      attach();
      const mo = new MutationObserver(()=> attach());
      mo.observe(document.documentElement, {childList:true, subtree:true});
    });
  }
  ready(install);
})();