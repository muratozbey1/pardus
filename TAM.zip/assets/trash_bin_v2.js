/* Trash Bin v2.5 — draggable + lock + context items (Open/Lock) + dblclick open + persist pos */
(function(){
  if (window.__TRASH_V25__) return; window.__TRASH_V25__ = true;

  const LS_POS  = 'trash_pos';
  const LS_LOCK = 'trash_lock';

  const ready = (fn)=> document.readyState!=='loading' ? fn() : document.addEventListener('DOMContentLoaded', fn);
  const toast = (m)=> (window._showToast ? window._showToast(m,1800) : alert(m));

  function sanitizeId(raw){
    if (!raw) return '';
    return String(raw).replace(/^lnk-/, '').replace(/^fld-/, '').trim();
  }

  async function softDelOnce(type, id, owner, scope){
    const fd = new FormData();
    fd.append('action','soft_delete'); fd.append('type', type); fd.append('id', id);
    if (owner) fd.append('owner', owner);
    if (scope) fd.append('scope', scope);
    const r = await fetch('api_trash.php', {method:'POST', body:fd, credentials:'same-origin'});
    const j = await r.json().catch(()=>({ok:false,error:'Sunucu yanıtı okunamadı'}));
    return j;
  }
  async function softDel(type, id, owner){
    let j = await softDelOnce(type, id, owner||'', owner ? 'user':'global');
    if (j && j.ok) return j;
    if (j && /bulunamad[ıi]/i.test(j.error||'')){
      j = await softDelOnce(type, id, '', 'global');
    }
    return j;
  }

  function ensureWrap(){
    let el = document.getElementById('trashBin');
    if (!el){
      el = document.createElement('div'); el.id='trashBin';
      el.innerHTML = "<div class='bin' title='Çöp Kutusu'><i class='fa-solid fa-trash-can'></i></div>";
      document.body.appendChild(el);
    }
    return el;
  }
  function applyPos(wrap){
    const r = JSON.parse(localStorage.getItem(LS_POS)||'{}');
    const vw = window.innerWidth, vh = window.innerHeight;
    const pad = 12, panel = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--panel-h'))||36;
    let x,y;
    if (typeof r.x==='number' && typeof r.y==='number'){
      x = Math.min(vw - 46 - pad, Math.max(pad, r.x));
      y = Math.min(vh - 46 - (panel+pad), Math.max(pad, r.y));
    }else{
      x = vw - 46 - pad;
      y = vh - 46 - (panel+pad);
    }
    wrap.style.left = x + 'px'; wrap.style.top = y + 'px';
  }
  function setLockUI(binEl, locked){
    binEl.style.cursor = locked ? 'not-allowed' : 'move';
    binEl.title = locked ? 'Çöp Kutusu (Kilidi Kapalı)' : 'Çöp Kutusu (Kilidi Açık)';
  }
  function bindDrag(wrap){
    const bin = wrap.querySelector('.bin');
    let down=false, sx=0, sy=0, sl=0, st=0;
    bin.addEventListener('pointerdown', (e)=>{
      const locked = localStorage.getItem(LS_LOCK)==='1';
      if (locked) return; // kilitliyken sürükleme yok
      down = true;
      const r = wrap.getBoundingClientRect();
      sx = e.clientX; sy = e.clientY; sl = r.left; st = r.top;
      bin.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    document.addEventListener('pointermove', (e)=>{
      if (!down) return;
      const vw = window.innerWidth, vh = window.innerHeight;
      const pad = 8, panel = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--panel-h'))||36;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      let nx = Math.min(vw - 46 - pad, Math.max(pad, sl + dx));
      let ny = Math.min(vh - 46 - (panel+pad), Math.max(pad, st + dy));
      wrap.style.left = nx + 'px'; wrap.style.top = ny + 'px';
    });
    document.addEventListener('pointerup', (e)=>{
      if (!down) return; down=false;
      const r = wrap.getBoundingClientRect();
      localStorage.setItem(LS_POS, JSON.stringify({x:r.left,y:r.top}));
    });
    window.addEventListener('resize', ()=> applyPos(wrap));
  }

  function ctxDelete(target){
    if (!target) return;
    const U = (window.SOFTDESK_USER||{});
    const owner = (U && U.logged && U.email) ? U.email : '';
    const dataId = sanitizeId(target.dataset && target.dataset.id);
    const isFolder = /^f_/.test(dataId);
    const isLink = !!(target.dataset && target.dataset.linkId);

    if (isLink){
      const id = sanitizeId(target.dataset.linkId);
      softDel('link', id, owner).then(j=>{
        if(j && j.ok){ try{ target.remove(); }catch(e){} toast('Kısayol çöpe taşındı'); if(window.loadFolders) window.loadFolders(); }
        else toast(j.error||'Silinemedi');
      });
    } else if (isFolder){
      softDel('folder', dataId, owner).then(j=>{
        if(j && j.ok){ try{ target.remove(); }catch(e){} toast('Klasör çöpe taşındı'); if(window.loadFolders) window.loadFolders(); }
        else toast(j.error||'Silinemedi');
      });
    } else {
      toast('Öge algılanamadı');
    }
  }

  ready(function(){
    // style
    const st = document.createElement('style'); st.textContent = `
      #trashBin{position:fixed; z-index:15000; user-select:none}
      #trashBin .bin{ width:46px;height:46px;border-radius:12px;border:1px solid var(--line);
        background:#0f1115cc; display:grid; place-items:center; backdrop-filter:blur(6px) }
      #trashBin .bin i{font-size:18px;color:#ef4444}
      #trashBin .bin.hot{outline:2px solid #ef4444; transform: scale(1.06);}
    `; document.head.appendChild(st);

    const wrap = ensureWrap(); applyPos(wrap); bindDrag(wrap);
    const bin = wrap.querySelector('.bin');
    setLockUI(bin, localStorage.getItem(LS_LOCK)==='1');

    // bin'i çift tıkla aç
    bin.addEventListener('dblclick', function(){
      if (window.openTrashUI) window.openTrashUI();
      else toast('Çöp UI yüklü değil');
    });

    // sürüklenen öge bin üstündeyse görsel uyarı + bırakınca sil
    let draggingItem=null;
    document.addEventListener('pointerdown', function(e){
      const it = (e.target && e.target.closest) ? e.target.closest('.item') : null;
      if (it) draggingItem = it;
    }, true);
    document.addEventListener('pointermove', function(e){
      if (!draggingItem) return;
      const r = bin.getBoundingClientRect();
      bin.classList.toggle('hot', (e.clientX>=r.left && e.clientX<=r.right && e.clientY>=r.top && e.clientY<=r.bottom));
    }, true);
    document.addEventListener('pointerup', function(e){
      const r = bin.getBoundingClientRect();
      const inside = (e.clientX>=r.left && e.clientX<=r.right && e.clientY>=r.top && e.clientY<=r.bottom);
      bin.classList.remove('hot');
      if (inside && draggingItem){ ctxDelete(draggingItem); }
      draggingItem=null;
    }, true);

    // SAĞ TIK MENÜ ENTEGRASYONU
    const menu = document.getElementById('ctxMenu');
    if (menu){
      // 1) Sil (Çöpe) — varsa tekrar oluşturma
      let del = document.getElementById('ctxDelete');
      if (!del){
        del = document.createElement('div'); del.className='citem'; del.id='ctxDelete';
        del.innerHTML="<i class='fa-solid fa-trash' style='color:#ef4444'></i><span>Sil (Çöpe)</span>";
        menu.appendChild(del);
      }
      del.addEventListener('click', function(e){ e.preventDefault(); e.stopPropagation(); var tgt = window.__CTX_TARGET || null; if (!tgt) return; ctxDelete(tgt); });
      // 2) Çöp Kutusunu Aç
      let op = document.getElementById('ctxOpenTrash');
      if (!op){
        op = document.createElement('div'); op.className='citem'; op.id='ctxOpenTrash';
        op.innerHTML="<i class='fa-regular fa-trash-can' style='color:#60a5fa'></i><span>Çöp Kutusunu Aç</span>";
        menu.appendChild(op);
      }
      op.addEventListener('click', function(e){ e.preventDefault(); e.stopPropagation(); if (window.openTrashUI) window.openTrashUI(); else toast('Çöp UI yüklü değil'); });

      // 3) Çöpü Kilitle / Kilidi Aç
      let lk = document.getElementById('ctxLockTrash');
      if (!lk){
        lk = document.createElement('div'); lk.className='citem'; lk.id='ctxLockTrash';
        lk.innerHTML="<i class='fa-solid fa-lock' style='color:#f59e0b'></i><span>Çöpü Kilitle</span>";
        menu.appendChild(lk);
      }
      function refreshLockLabel(){
        const locked = localStorage.getItem(LS_LOCK)==='1';
        lk.querySelector('i').className = locked ? 'fa-solid fa-lock-open' : 'fa-solid fa-lock';
        lk.querySelector('span').textContent = locked ? 'Çöp Kilidini Aç' : 'Çöpü Kilitle';
        setLockUI(bin, locked);
      }
      lk.addEventListener('click', function(e){
        e.preventDefault(); e.stopPropagation();
        const locked = localStorage.getItem(LS_LOCK)==='1';
        if (locked) localStorage.removeItem(LS_LOCK); else localStorage.setItem(LS_LOCK,'1');
        refreshLockLabel();
      });
      refreshLockLabel();

      // bağlam menüsü hedef takibi
      document.addEventListener('contextmenu', function(e){
        var it = (e.target && e.target.closest) ? e.target.closest('.item') : null;
        window.__CTX_TARGET = it;
        del.style.display = it ? '' : 'none'; // Sil (Çöpe) sadece item varsa
        op.style.display = '';                 // Çöpü Aç her zaman
        lk.style.display = '';                 // Kilitle/Aç her zaman
      }, true);
    }
  });
})();