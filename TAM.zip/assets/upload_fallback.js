/* assets/upload_fallback.js — Ctrl+U global uploader (independent) */
(function(){
  if (window.__PARDUS_UPLOAD_FALLBACK__) return;
  window.__PARDUS_UPLOAD_FALLBACK__ = true;

  const API = 'api.php'; // uses action=upload_files

  function el(tag, props={}, kids=[]){
    const e=document.createElement(tag);
    Object.assign(e, props);
    kids.forEach(k=>e.appendChild(typeof k==='string'?document.createTextNode(k):k));
    return e;
  }

  function styleOnce(){
    if (document.getElementById('upload-fallback-style')) return;
    const st = el('style', {id:'upload-fallback-style'});
    st.textContent = `
    .uplf-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);display:grid;place-items:center;z-index:99999}
    .uplf{width:560px;max-width:92vw;background:#0f1117;color:#e6e9ee;border:1px solid #2a2f38;border-radius:14px;box-shadow:0 20px 48px rgba(0,0,0,.45);overflow:hidden}
    .uplf-h{padding:12px 14px;font-weight:700;background:#171b24;border-bottom:1px solid #2a2f38}
    .uplf-b{padding:14px;display:grid;gap:10px}
    .uplf input[type=file]{width:100%;border:1px solid #2a2f38;border-radius:10px;padding:10px;background:#0d1118;color:#e6e9ee}
    .uplf select{width:100%;border:1px solid #2a2f38;border-radius:10px;padding:10px;background:#0d1118;color:#e6e9ee}
    .uplf .row{display:grid;gap:6px}
    .uplf .acts{display:flex;gap:8px;justify-content:flex-end}
    .uplf button{height:36px;padding:0 14px;border-radius:10px;border:1px solid #2a2f38;background:#1b2230;color:#e6e9ee;cursor:pointer}
    .uplf .ghost{background:#121720}
    .uplf .prog{height:10px;background:#121720;border:1px solid #2a2f38;border-radius:6px;overflow:hidden}
    .uplf .bar{height:100%;width:0%;background:#22c55e;transition:width .2s}
    .uplf small{opacity:.75}
    `;
    document.head.appendChild(st);
  }

  async function listFolders(){
    const r = await fetch(API+'?action=list_folders', {credentials:'same-origin', cache:'no-store'});
    const j = await r.json().catch(()=>({}));
    return Array.isArray(j.folders) ? j.folders : [];
  }

  function openDialog(prefFolder){
    styleOnce();
    const ov = el('div',{className:'uplf-overlay'});
    const box = el('div',{className:'uplf'});
    const head = el('div',{className:'uplf-h'},[document.createTextNode('Dosya Yükle (Ctrl+U)')]);
    const body = el('div',{className:'uplf-b'});
    const rowTarget = el('div',{className:'row'});
    rowTarget.append(el('label',{textContent:'Hedef klasör:'}));
    const sel = el('select');
    rowTarget.append(sel);
    const rowFiles = el('div',{className:'row'});
    rowFiles.append(el('label',{textContent:'Dosyalar:'}));
    const inp = el('input',{type:'file', multiple:true});
    rowFiles.append(inp);
    const hint = el('small',{textContent:'İpucu: Pencereye dosya sürükleyip bırakabilirsiniz.'});
    const prog = el('div',{className:'prog'}); const bar=el('div',{className:'bar'}); prog.append(bar);
    const acts = el('div',{className:'acts'});
    const btnCancel = el('button',{className:'ghost',textContent:'İptal'});
    const btnUpload = el('button',{textContent:'Yükle'});
    acts.append(btnCancel, btnUpload);
    body.append(rowTarget,rowFiles,hint,prog,acts);
    box.append(head, body); ov.append(box); document.body.appendChild(ov);

    ov.addEventListener('click', (e)=>{ if(e.target===ov) close(); });
    btnCancel.onclick = close;
    function close(){ ov.remove(); }

    function setBar(p){ bar.style.width = Math.max(0,Math.min(100,p))+'%'; }

    ov.addEventListener('dragover',(e)=>{ e.preventDefault(); });
    ov.addEventListener('drop',(e)=>{
      e.preventDefault();
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length){
        inp.files = e.dataTransfer.files;
      }
    });

    // load folders
    (async ()=>{
      let list = await listFolders();
      // fallback if empty
      if (!list.length && prefFolder){ list = [{id:prefFolder, name:prefFolder}]; }
      list.forEach(f=>{
        const opt = el('option',{value:String(f.name||f.id||'').trim(), textContent: (f.name||'Klasör')});
        sel.append(opt);
      });
      // preselect
      const target = String(prefFolder||'').trim();
      if (target){
        const opt = Array.from(sel.options).find(o=>o.value===target);
        if (opt) sel.value = target;
      }
    })();

    btnUpload.onclick = ()=>{
      const files = inp.files ? Array.from(inp.files) : [];
      if (!files.length){ alert('Lütfen en az bir dosya seçin'); return; }
      const target = sel.value || prefFolder || '';
      const fd = new FormData();
      fd.append('action','upload_files');
      fd.append('folder', target);
      files.forEach(f=>fd.append('files[]', f, f.name));

      const xhr = new XMLHttpRequest();
      xhr.open('POST', API);
      xhr.withCredentials = true;
      xhr.upload.onprogress = (e)=>{ if(e.lengthComputable){ setBar( (e.loaded/e.total)*100 ); } };
      xhr.onreadystatechange = ()=>{
        if(xhr.readyState===4){
          if(xhr.status>=200 && xhr.status<300){
            try{
              const res = JSON.parse(xhr.responseText);
              if(res && res.ok){
                setBar(100);
                setTimeout(close, 600);
                if (typeof window.refreshFileList === 'function'){ try{ window.refreshFileList(target); }catch(_e){} }
              } else {
                alert('Yükleme hatası: '+(res && (res.error||'bilinmiyor')));
              }
            }catch(_){ alert('Sunucu yanıtı okunamadı'); }
          } else {
            alert('HTTP '+xhr.status+' hata');
          }
        }
      };
      xhr.send(fd);
    };
  }

  // Ctrl+U kısayolu
  document.addEventListener('keydown', (e)=>{
    if ((e.ctrlKey||e.metaKey) && (e.key==='u' || e.key==='U')){
      e.preventDefault();
      // tahmini aktif klasör: seçili iconun label'ı
      let pref = ''; const sel = document.querySelector('.item.selected .flabel');
      if (sel) pref = (sel.textContent||'').trim();
      openDialog(pref);
    }
  });

  console.log('[upload_fallback] hazır: Ctrl+U ile açılır');
})();