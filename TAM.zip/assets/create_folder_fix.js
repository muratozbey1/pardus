/* Robust folder-create helper with credentials & hard guard + instant UI update */
(function(){
  if (window.__CFIX_BOUND) return; window.__CFIX_BOUND = true;
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function iconHTML(spec){
    if(!spec) return "<i class='fa-regular fa-folder' style='color:#8ab4f8'></i>";
    if(spec.startsWith('fa:')){
      let cls=spec.substring(3), colr=null; const p=cls.indexOf("|");
      if(p>-1){ colr=cls.substring(p+1); cls=cls.substring(0,p); }
      return "<i class='"+cls+"'"+(colr?(" style='color:"+colr+"'"):"")+"></i>";
    }
    return "<i class='fa-regular fa-folder' style='color:#8ab4f8'></i>";
  }
  function place(el,key,col,row){
    const grid = document.getElementById('grid');
    if (!grid) return;
    const r=grid.getBoundingClientRect(); const PAD=10, ICON_W=96, ICON_H=96;
    const x = PAD + (col||0)*ICON_W, y = PAD + (row||0)*ICON_H;
    el.style.left = x+'px'; el.style.top = y+'px';
  }
  function addFolderInstant(id, name, icon){
    try{
      const grid = document.getElementById('grid'); if (!grid) return;
      const el=document.createElement('div'); el.className='item'; el.dataset.id=id;
      el.innerHTML = "<div class='ficon'>"+iconHTML(icon)+"</div><div class='flabel'>"+(name||'Klasör')+"</div>";
      el.addEventListener('click', function(){ if (el._dragged) return; if (window.openWindowEx) window.openWindowEx({id:'fld-'+id,title:name||'Klasör',html:"<div style='padding:8px'>"+(name||'Klasör')+" klasörü.</div>",w:560,h:400}); });
      grid.appendChild(el);
      if (window.dragify) window.dragify(el,'fld-'+id); else place(el,'fld-'+id,0,1);
    }catch(e){}
  }
  ready(function(){
    var btn = document.getElementById('btnCreate');
    if (!btn) { return; }
    btn.addEventListener('click', async function(e){
      if (e) { try{ e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); }catch(_){ } }
      try{
        var U = window.SOFTDESK_USER||{logged:false};
        if(!U.logged){ (window._showToast||alert)('Klasör oluşturmak için giriş yapınız.'); return false; }
        var nameEl = document.getElementById('fldName');
        var iconEl = document.getElementById('fldIcon');
        var name = (nameEl && nameEl.value||'').trim();
        var icon = (iconEl && iconEl.value)||'';
        if(!name){ (window._showToast||alert)('İsim gerekli'); return false; }
        const fd = new FormData();
        fd.append('action','create_folder');
        fd.append('name', name);
        fd.append('icon', icon);
        const r = await fetch('api.php', { method:'POST', body:fd, credentials:'same-origin', cache:'no-store' });
        const j = await r.json().catch(()=>({ok:false,error:'Sunucu yanıtı okunamadı'}));
        if(!j.ok){ (window._showToast||alert)(j.error||'Oluşturulamadı'); return false; }
        // Hemen UI'ye yansıt
        addFolderInstant(j.id || ('f_tmp_'+Date.now()), name, icon);
        if (window._showToast) window._showToast('Klasör oluşturuldu', 1800);
        try{ document.getElementById('modal').style.display='none'; }catch(_){}
        // Sonradan kesin eşitle (yeniden yükle)
        setTimeout(function(){
          if (window.loadFolders) window.loadFolders();
          else location.reload();
        }, 250);
      }catch(_){ (window._showToast||alert)('İşlem başarısız'); }
      return false;
    }, true);
    console.debug('[create_folder_fix] aktif (v4.4)');
  });
})();