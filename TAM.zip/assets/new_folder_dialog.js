/* Global: openNewFolderDialog (minimal, temayı bozmaz) */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function toast(msg, ms){ if (window._showToast) window._showToast(msg, ms||1800); else alert(msg); }
  window.openNewFolderDialog = function(){
    var U = window.SOFTDESK_USER || {};
    if (!U.logged) { toast('Klasör oluşturmak için giriş yapınız.', 2000); return; }
    var modal = document.getElementById('modal');
    var fldName = document.getElementById('fldName');
    if (!modal) { toast('Yeni Klasör penceresi sayfada bulunamadı.', 2000); return; }
    try{ modal.style.display = 'flex'; }catch(e){}
    if (fldName){ try{ fldName.value=''; setTimeout(function(){ fldName.focus(); }, 60); }catch(e){} }
  };
  ready(function(){
    var ctx = document.getElementById('ctxNew');
    if (ctx){
      ctx.addEventListener('click', function(e){
        e.preventDefault(); e.stopPropagation();
        if (typeof window.openNewFolderDialog === 'function') window.openNewFolderDialog();
      }, true);
    }
  });
})();