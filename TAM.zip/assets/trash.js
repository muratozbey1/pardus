/* Simple trash window to delete folders */
(function(){
  if (window.openTrashMini) return;
  window.openTrashMini = function(){
    const html = `
    <style>
      .t-mini{padding:8px;font-size:12.5px}
      .t-mini table{width:100%;border-collapse:collapse}
      .t-mini th,.t-mini td{border-bottom:1px solid var(--line);padding:6px;text-align:left}
      .t-mini .btnx{padding:4px 8px;border:1px solid var(--line);background:#1e2634;border-radius:8px;color:#fff;cursor:pointer}
      .t-mini .mut{color:#9aa6b2}
    </style>
    <div class="t-mini">
      <div class="mut" style="margin-bottom:6px">Klasör silme — sadece kendi klasörlerini silebilirsin (admin hepsini görür).</div>
      <div id="twrap">Yükleniyor...</div>
    </div>`;
    const w = openWindowEx({ id:'trash', title:'Çöp Kutusu', html:html, w:520, h:360 });
    const wrap = w.querySelector('#twrap');
    function load(){
      fetch('api.php?action=list_folders',{cache:'no-store',credentials:'same-origin'}).then(r=>r.json()).then(j=>{
        const arr = (j.folders||[]);
        if(arr.length===0){ wrap.textContent='Klasör yok'; return; }
        const rows = arr.map(f=>{
          const owner = f.owner?`<td class="mut">${f.owner}</td>`:'';
          return `<tr data-id="${f.id}" data-owner="${f.owner||''}">
            <td>${(f.name||'Klasör')}</td>
            ${owner}
            <td><button class="btnx" data-del>Sil</button></td></tr>`;
        }).join('');
        const thOwner = (arr.some(f=>!!f.owner))?'<th>Sahip</th>':'';
        wrap.innerHTML = `<div style="overflow:auto"><table><thead><tr><th>Ad</th>${thOwner}<th>İşlem</th></tr></thead><tbody>${rows}</tbody></table></div>`;
        wrap.querySelectorAll('[data-del]').forEach(btn=>{
          btn.onclick = function(){
            const tr = btn.closest('tr');
            const id = tr.getAttribute('data-id');
            const owner = tr.getAttribute('data-owner')||'';
            if(!confirm('Klasörü silmek istediğinize emin misiniz?')) return;
            const fd = new FormData(); fd.append('action','delete_folder'); fd.append('id', id);
            if(owner) fd.append('owner', owner);
            fetch('api.php',{method:'POST',body:fd,credentials:'same-origin'}).then(r=>r.json()).then(j2=>{
              if(!j2.ok){ alert(j2.error||'Silinemedi'); return; }
              load();
            }).catch(()=>alert('Hata'));
          };
        });
      }).catch(()=>{ wrap.textContent='Hata'; });
    }
    load();
  };
})();