/* Terminal + Next Wallpaper + Create Shortcut; exports openTerminal */
(function(){
  if (window.openTerminal) return;
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function ensureCtxItem(id, html, onClick){
    var menu = document.getElementById('ctxMenu'); if(!menu) return;
    var el = document.getElementById(id);
    if(!el){
      el = document.createElement('div'); el.className='citem'; el.id=id; el.innerHTML = html;
      menu.appendChild(el);
    }
    el.onclick = function(e){ e.preventDefault(); e.stopPropagation(); onClick && onClick(); };
  }
  window.openTerminal = function(){
    var html = `
    <style>
      .term{background:#0b0e14;height:100%;display:flex;flex-direction:column}
      .term .out{flex:1;padding:10px;font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;font-size:12.5px;white-space:pre-wrap;overflow:auto}
      .term .inp{display:flex;gap:6px;padding:8px;border-top:1px solid #242938}
      .term input{flex:1;padding:8px;border-radius:8px;border:1px solid #2a2f3b;background:#0f1115;color:#e6e9ee}
      .term button{padding:8px 12px;border-radius:8px;border:1px solid #2a2f3b;background:#1d2330;color:#fff;cursor:pointer}
      .term .prompt{color:#a3e635}
    </style>
    <div class="term">
      <div class="out" id="tout"></div>
      <div class="inp"><span class="prompt">$</span><input id="tin" placeholder='help, whoami, ls, mkdir "ad", rm <id>, links, mklink "Başlık" <url>, wallpaper next, clear, logout'><button id="tgo">Gönder</button></div>
    </div>`;
    var w = openWindowEx({ id:'terminal', title:'Uçbirim', html:html, w:680, h:380 });
    var out = w.querySelector('#tout'), inp = w.querySelector('#tin'), go = w.querySelector('#tgo');
    function log(s){ out.textContent += (s+'\n'); out.scrollTop = out.scrollHeight; }
    function cmdline(){ return (inp.value||'').trim(); }
    async function run(){
      var c = cmdline(); if(!c) return; log('> '+c); inp.value='';
      var parts = c.match(/"[^"]*"|\S+/g)||[]; parts = parts.map(p=>p.replace(/^"|"$/g,''));
      var cmd = parts[0]; var rest = parts.slice(1);
      try{
        if (cmd==='help'){
          log('Komutlar: help, whoami, date, ls, mkdir <ad>, rm <id>, links, mklink "Başlık" <url>, wallpaper next, clear, logout');
        } else if (cmd==='clear'){
          out.textContent='';
        } else if (cmd==='date'){
          log(new Date().toString());
        } else if (cmd==='whoami'){
          var U = window.SOFTDESK_USER||{};
          log((U.username||'(misafir)')+' ['+(U.role||'guest')+'] '+(U.email||''));
        } else if (cmd==='ls'){
          var r = await fetch('api.php?action=list_folders',{cache:'no-store',credentials:'same-origin'});
          var j = await r.json(); (j.folders||[]).forEach(f=>log((f.id||'')+'  '+(f.name||'Klasör')+(f.owner?('  ('+f.owner+')'):'') ));
          if (!(j.folders||[]).length) log('(boş)');
        } else if (cmd==='links'){
          var rL = await fetch('api.php?action=list_links',{cache:'no-store',credentials:'same-origin'});
          var jL = await rL.json(); (jL.links||[]).forEach(l=>log((l.id||'')+'  '+(l.title||'')+' -> '+(l.url||'')));
          if (!(jL.links||[]).length) log('(yok)');
        } else if (cmd==='mklink'){
          var title = rest[0]||''; var url = rest[1]||''; if(!title||!url){ log('Kullanım: mklink "Başlık" https://...'); return; }
          if(!/^https?:\/\//i.test(url)) url = 'https://'+url;
          var fd=new FormData(); fd.append('action','create_link'); fd.append('title', title); fd.append('url', url); fd.append('icon','fa:fa-solid fa-up-right-from-square|#8ab4f8');
          var r2=await fetch('api.php',{method:'POST',body:fd,credentials:'same-origin'}); var j2=await r2.json(); log(j2.ok?'ok: '+(j2.id||'') : ('hata: '+(j2.error||'')));
        } else if (cmd==='mkdir'){
          var name = rest.join(' ').trim(); if(!name){ log('Kullanım: mkdir <ad>'); return; }
          var fd = new FormData(); fd.append('action','create_folder'); fd.append('name', name); fd.append('icon','fa:fa-regular fa-folder|#8ab4f8');
          var r2 = await fetch('api.php',{method:'POST',body:fd,credentials:'same-origin'}); var j2=await r2.json(); log(j2.ok?'ok: '+(j2.id||'') : ('hata: '+(j2.error||'')));
        } else if (cmd==='rm'){
          var id = rest.join(' ').trim(); if(!id){ log('Kullanım: rm <id>'); return; }
          var fd = new FormData(); fd.append('action','delete_folder'); fd.append('id', id);
          var r3 = await fetch('api.php',{method:'POST',body:fd,credentials:'same-origin'}); var j3=await r3.json(); log(j3.ok?'silindi':'hata: '+(j3.error||''));
        } else if (cmd==='wallpaper' && rest[0]==='next'){
          if (window.wallpaperNext) window.wallpaperNext(); else log('duvar kağıdı modülü yok');
        } else if (cmd==='logout'){
          try{ localStorage.setItem('SOFTDESK_TOAST','logout-ok'); }catch(e){}
          await fetch('auth/logout.php?inapp=1',{cache:'no-store',credentials:'same-origin'});
          location.reload();
        } else {
          log('Bilinmeyen komut. help yazın.');
        }
      }catch(e){ log('Hata'); }
    }
    go.onclick = run; inp.addEventListener('keydown',function(e){ if(e.key==='Enter') run(); });
    setTimeout(function(){ inp.focus(); }, 50);
    log('Uçbirim hazır. help yazarak başlayın.');
  };

  function nextWallpaper(){ if (window.wallpaperNext) window.wallpaperNext(); }
  function createShortcut(){
    if (window.openShortcutMini) window.openShortcutMini();
    else { var s=document.createElement('script'); s.src='assets/links_runtime.js'; document.head.appendChild(s); s.onload=function(){ if(window.openShortcutMini) window.openShortcutMini(); }; }
  }

  document.addEventListener('DOMContentLoaded', function(){
    ensureCtxItem('ctxTerm', "<i class='fa-solid fa-terminal' style='color:#a78bfa'></i><span>Uçbirim</span>", window.openTerminal);
    ensureCtxItem('ctxNextWall', "<i class='fa-regular fa-image' style='color:#60a5fa'></i><span>Sonraki Duvar Kağıdı</span>", nextWallpaper);
    ensureCtxItem('ctxShortcut', "<i class='fa-solid fa-link' style='color:#38bdf8'></i><span>Kısayol Oluştur</span>", createShortcut);
  });
})();