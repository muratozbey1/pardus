// app_router.js — index.php?app=admin gibi linkleri pencere içinde aç
(function(){
  const params = new URLSearchParams(location.search);
  const app = params.get('app');
  if(!app) return;

  const map = {
    'admin': 'admin/index.php?inapp=1',
    'login': 'auth/login.php?inapp=1',
    'register': 'auth/register.php?inapp=1'
  };
  const titleMap = { admin:'Admin', login:'Giriş', register:'Kullanıcı Oluştur' };
  const url = map[app];
  if(!url) return;

  // index tarafında openAppWindow yoksa pencere komponeni hazırla
  if (typeof window.openAppWindow !== 'function') {
    window.openAppWindow = function(title, src, w, h){
      const html = "<iframe src='"+src+"' style='border:0;width:100%;height:100%'></iframe>";
      if (window.openWindowEx) { window.openWindowEx({id:'app-'+app, title:title, html:html, w:w||980, h:h||640}); }
      else { location.href = src; }
    };
  }
  window.openAppWindow(titleMap[app]||'Uygulama', url, 980, 640);

  // app parametresini URL’den kaldır (güzel URL)
  history.replaceState({}, document.title, location.pathname);
})();