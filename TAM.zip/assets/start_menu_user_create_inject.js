/* Start menu: add "Kullanıcı Oluştur" entry (tiny window) */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  ready(function(){
    try{
      var ul = document.getElementById('menuStatic') || document.querySelector('#menu .list');
      if(!ul) return;
      if(document.getElementById('mUserCreate')) return; // avoid dup
      var li = document.createElement('li');
      li.className='it'; li.id='mUserCreate';
      li.innerHTML = "<i class='fa-regular fa-user' style='color:#22c55e'></i><span>Kullanıcı Oluştur</span>";
      li.addEventListener('click', function(){
        try{ document.getElementById('menu').classList.remove('open'); }catch(e){}
        if (window.openRegisterMini) window.openRegisterMini();
        else alert('register_mini.js yüklenemedi');
      });
      // Insert before Exit if exists
      var exit = document.getElementById('mExit');
      if(exit && exit.parentNode===ul){ ul.insertBefore(li, exit); } else { ul.appendChild(li); }
    }catch(e){ /* silent */ }
  });
})();