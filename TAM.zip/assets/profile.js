/* Small Profile window helper (export openProfileMini) */
(function(){
  if (window.openProfileMini) return;
  window.openProfileMini = function(){
    const html = `
    <style>
      .p-mini{padding:10px;font-size:12.5px}
      .p-mini .g{display:grid;grid-template-columns:110px 1fr;gap:8px;align-items:center}
      .p-mini label{color:#c7d0df}
      .p-mini input{width:100%;padding:8px;border-radius:8px;border:1px solid var(--line);background:#0f1115;color:#e6e9ee}
      .p-mini .row{margin:4px 0}
      .p-mini .tool{display:flex;gap:8px;justify-content:flex-end;margin-top:8px}
      .p-mini .hint{color:#9aa3b2;margin-top:6px}
      .p-mini .ok{color:#22c55e}
      .p-mini .err{color:#ef4444}
      .p-mini .sm{font-size:12px}
      .avatar{display:flex;gap:8px;flex-wrap:wrap;margin-top:6px}
      .preset{border:1px solid var(--line);border-radius:10px;padding:6px 8px;cursor:pointer}
      .preset.sel{outline:2px solid #3b82f6}
    </style>
    <div class="p-mini">
      <form id="pForm">
        <div class="g">
          <label>Ad</label><input name="first_name" required>
          <label>Soyad</label><input name="last_name" required>
          <label>Telefon</label><input name="phone">
          <label>Şehir</label><input name="city">
          <label>Avatar</label>
          <div>
            <div class="avatar" id="presetAv"></div>
            <div class="row sm">veya dosya yükle: <input type="file" name="avatar_file" accept="image/png,image/jpeg,image/webp"></div>
          </div>
        </div>
        <div class="hint sm">Değişiklikler yalnızca kendi profilinize uygulanır.</div>
        <div id="msg" class="sm"></div>
        <div class="tool">
          <button type="button" id="btnCancel" class="btn">Kapat</button>
          <button type="submit" class="btn">Kaydet</button>
        </div>
      </form>
    </div>`;
    const w = openWindowEx({ id:'user-profile', title:'Profil', html:html, w:480, h:420 });
    const f = w.querySelector('#pForm'), msg = w.querySelector('#msg'), presets = w.querySelector('#presetAv');
    const btnCancel = w.querySelector('#btnCancel'); if (btnCancel) btnCancel.onclick = ()=>{ w.style.display='none'; };
    const list = ['p1','p2','p3','p4','p5','p6']; let sel=null;
    list.forEach(function(k,i){ const b=document.createElement('button'); b.type='button'; b.className='preset'; b.textContent='Avatar '+(i+1); b.onclick=function(){ Array.from(presets.children).forEach(x=>x.classList.remove('sel')); b.classList.add('sel'); sel=k; }; presets.appendChild(b); });
    fetch('auth/profile_get.php',{credentials:'same-origin'}).then(r=>r.json()).then(j=>{
      if(!j.ok){ msg.textContent=j.error||'Yüklenemedi'; msg.className='sm err'; return; }
      ['first_name','last_name','phone','city'].forEach(k=>{ if(j.profile && j.profile[k]!=null) f.elements[k].value = j.profile[k]; });
    });
    f.onsubmit = async function(e){
      e.preventDefault(); msg.textContent='Kaydediliyor...'; msg.className='sm';
      const fd=new FormData(f); if(sel) fd.append('avatar_preset', sel);
      try{
        const r=await fetch('auth/profile_update.php',{method:'POST',body:fd,credentials:'same-origin'});
        const j=await r.json(); if(!j.ok){ msg.textContent=j.error||'Hata'; msg.className='sm err'; return; }
        msg.textContent='Güncellendi'; msg.className='sm ok';
        setTimeout(()=>location.reload(), 400);
      }catch(e){ msg.textContent='İşlem başarısız'; msg.className='sm err'; }
    };
  };
})();