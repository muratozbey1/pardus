(function(){
  if (window.openLoginMini) return;
  window.openLoginMini = function(){
    const html = `
    <style>
      .l-mini{padding:10px;font-size:12.5px}
      .l-mini .g{display:grid;grid-template-columns:110px 1fr;gap:8px;align-items:center}
      .l-mini label{color:#c7d0df}
      .l-mini input{width:100%;padding:8px;border-radius:8px;border:1px solid var(--line);background:#0f1115;color:#e6e9ee}
      .l-mini .tool{display:flex;gap:8px;justify-content:flex-end;margin-top:8px}
      .l-mini .ok{color:#22c55e}.l-mini .err{color:#ef4444}.l-mini .sm{font-size:12px}
    </style>
    <form id="lForm" class="l-mini">
      <div class="g">
        <label>E-posta</label><input name="email" type="email" required>
        <label>Şifre</label><input name="password" type="password" required>
      </div>
      <div id="msg" class="sm"></div>
      <div class="tool">
        <button type="button" id="btnCancel" class="btn">Kapat</button>
        <button type="submit" class="btn">Giriş</button>
      </div>
    </form>`;
    const w = openWindowEx({ id:'login-mini', title:'Giriş', html:html, w:380, h:240 });
    const f = w.querySelector('#lForm'), msg=w.querySelector('#msg'), btnCancel=w.querySelector('#btnCancel');
    if (btnCancel) btnCancel.onclick = ()=>{ w.style.display='none'; };
    f.onsubmit = async function(e){
      e.preventDefault(); msg.textContent='Gönderiliyor...'; msg.className='sm';
      const fd = new FormData(f);
      try{
        const r=await fetch('auth/login_post.php',{method:'POST',body:fd,credentials:'same-origin'});
        if (r.redirected || r.ok) { try{localStorage.setItem('SOFTDESK_TOAST','login-ok');}catch(e){} location.reload(); return; }
        msg.textContent='E-posta veya şifre hatalı'; msg.className='sm err';
      }catch(e){ msg.textContent='Hata'; msg.className='sm err'; }
    };
  };
})();