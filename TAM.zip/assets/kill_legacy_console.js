/* assets/kill_legacy_console.js — remove/ban the legacy "Konsol (Log)" panel */
(function(){
  if (window.__PARDUS_KILL_LEGACY_CONSOLE__) return;
  window.__PARDUS_KILL_LEGACY_CONSOLE__ = true;

  // Titles to ban
  function isBannedTitle(t){
    if (!t) return false;
    const s = String(t).trim();
    return /^(konsol\s*\(log\))$/i.test(s) || /konsol.*log/i.test(s) || /^console\s*\(log\)$/i.test(s);
  }

  // Patch openWindow / openWindowEx to prevent opening banned titles
  try{
    if (typeof window.openWindow === 'function'){
      const _ow = window.openWindow;
      window.openWindow = function(title, html, w, h){
        if (isBannedTitle(title)) { console.info('[Pardus] Legacy Konsol (Log) açılışı engellendi'); return null; }
        return _ow.apply(this, arguments);
      };
    }
  }catch(_){}
  try{
    if (typeof window.openWindowEx === 'function'){
      const _ox = window.openWindowEx;
      window.openWindowEx = function(opts){
        try{
          const title = (opts && (opts.title || opts.name || opts.id)) || '';
          if (isBannedTitle(title)) { console.info('[Pardus] Legacy Konsol (Log) açılışı engellendi'); return null; }
        }catch(_){}
        return _ox.apply(this, arguments);
      };
    }
  }catch(_){}

  // Remove already-rendered instances
  function killExisting(root){
    const nodes = (root || document).querySelectorAll('*');
    nodes.forEach(function(n){
      if (!(n instanceof HTMLElement)) return;
      // Heuristics: window containers often have a header with title text
      // Look for elements whose innerText contains the banned title (small cost but robust)
      try{
        const txt = (n.getAttribute('data-title') || n.title || '').trim();
        if (isBannedTitle(txt)) { n.style.display='none'; n.remove(); return; }
        const header = n.querySelector && n.querySelector('.title, .hdr, .win-title, .window-title, [data-title]');
        const htxt = header ? (header.getAttribute('data-title') || header.textContent || '').trim() : '';
        if (isBannedTitle(htxt)) { const top = n.closest('.window, .win, .ui-window, [class*="window"], [id*="win"]') || n; top.remove(); }
      }catch(_){}
    });
  }

  // Initial sweep & observer
  killExisting(document);
  const mo = new MutationObserver((muts)=>{
    muts.forEach(m=>{
      m.addedNodes && m.addedNodes.forEach(n=>{
        if (!(n instanceof HTMLElement)) return;
        // If a new window subtree added, scan it
        killExisting(n);
      });
    });
  });
  mo.observe(document.documentElement, { childList:true, subtree:true });

  // Also remove any menu item that would open the legacy console
  document.addEventListener('click', function(ev){
    const el = ev.target && (ev.target.closest && ev.target.closest('[data-action], [data-cmd], .menu-item, .ctx-item, [onclick]'));
    if (!el) return;
    const label = (el.getAttribute('data-label') || el.textContent || '').trim();
    if (/konsol\s*\(log\)/i.test(label)){
      ev.stopPropagation(); ev.preventDefault();
      console.info('[Pardus] Legacy Konsol (Log) menüden engellendi');
      return false;
    }
  }, true);
})();