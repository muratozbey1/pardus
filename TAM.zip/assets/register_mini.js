(function(){
  if (window.openRegisterMini) return;
  window.openRegisterMini = function(){
    const html = `
    <style>
      .u-mini{padding:10px;font-size:12.5px}
      .u-mini .g{display:grid;grid-template-columns:110px 1fr;gap:8px;align-items:center}
      .u-mini label{color:#c7d0df}
      .u-mini input{width:100%;padding:8px;border-radius:8px;border:1px solid var(--line);background:#0f1115;color:#e6e9ee}
      .u-mini .row{margin:4px 0}
      .u-mini .tool{display:flex;gap:8px;justify-content:flex-end;margin-top:8px}
      .u-mini .hint{color:#9aa3b2;margin-top:6px}
      .u-mini .ok{color:#22c55e}
      .u-mini .err{color:#ef4444}
      .u-mini .sm{font-size:12px}
      .u-mini .sep{height:1px;background:#232732;margin:8px 0}
      .u-mini .toggle{cursor:pointer;color:#98b6ff}
    </style>
    <form id="userMiniForm" class="u-mini">
      <div class="g">
        <label>Ad</label><input name="first_name" autocomplete="off" required>
        <label>Soyad</label><input name="last_name" autocomplete="off" required>
        <label>E-posta</label><input name="email" type="email" autocomplete="off" required placeholder="kullanıcı adı olacaktır">
        <label>Şifre</label><input name="password" type="password" required>
      </div>
      <div class="row sm"><span class="toggle" id="advT">Telefon/Şehir</span></div>
      <div id="adv" style="display:none">
        <div class="g">
          <label>Telefon</label><input name="phone" autocomplete="off">
          <label>Şehir</label><input name="city" autocomplete="off">
        </div>
      </div>
      <div class="sep"></div>
      <div class="hint sm">E-posta kullanıcı adınız olur, her kullanıcı için bir klasör açılır.</div>
      <div id="msg" class="sm"></div>
      <div class="tool">
        <button type="button" id="btnCancel" class="btn">Kapat</button>
        <button type="submit" class="btn">Oluştur</button>
      </div>
    </form>`;
    const w = openWindowEx({ id:'user-create', title:'Kullanıcı Oluştur', html:html, w:420, h:360 });
    const f = w.querySelector('#userMiniForm');
    const msg = w.querySelector('#msg');
    const advT = w.querySelector('#advT');
    const adv = w.querySelector('#adv');
    const btnCancel = w.querySelector('#btnCancel');
    if (advT) advT.addEventListener('click', ()=>{ adv.style.display = adv.style.display==='none' ? 'block' : 'none'; });
    if (btnCancel) btnCancel.addEventListener('click', ()=>{ w.style.display='none'; });

    f.addEventListener('submit', async (e)=>{
      e.preventDefault();
      msg.textContent = 'Kaydediliyor...'; msg.className='sm';
      const fd = new FormData(f);
      try{
        const r = await fetch('auth/register_post.php', { method:'POST', body:fd, credentials:'same-origin' });
        const ct = r.headers.get('content-type')||'';
        let j=null;
        if (ct.includes('application/json')) j = await r.json(); else j = {ok:r.ok, message:(await r.text()).slice(0,200)};
        if (!j.ok){ msg.textContent = j.message || 'Hata oluştu'; msg.className='sm err'; return; }
        msg.textContent = 'Kullanıcı oluşturuldu. Giriş yapılıyor...'; msg.className='sm ok';
        setTimeout(()=>{ location.reload(); }, 500);
      }catch(err){
        msg.textContent = 'İşlem başarısız'; msg.className='sm err';
      }
    });
  };
})();