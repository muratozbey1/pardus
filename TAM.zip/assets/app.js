// Pardus-like desktop runtime (start menu, context menu, windows, clock)
(function(){
  const $  = (s,c=document)=>c.querySelector(s);
  const $$ = (s,c=document)=>Array.from(c.querySelectorAll(s));
  const grid = $("#grid");
  const tasks = $("#tasks");
  const startBtn = $("#startBtn");
  const startMenu = $("#startMenu");
  const ctx = $("#ctx");
  const status = $("#status");
  const clock = $("#clock");
  const reloadBtn = $("#reload");
  let startOpen = false;

  // -------- Clock --------
  function tick(){
    const d = new Date();
    const hh = String(d.getHours()).padStart(2,"0");
    const mm = String(d.getMinutes()).padStart(2,"0");
    clock.textContent = `${hh}:${mm}`;
  }
  setInterval(tick, 1000); tick();

  // -------- Window system --------
  let winCounter = 0;
  function makeWindow({title="Pencere", html=""}){
    const id = "win_"+(++winCounter);
    const w = document.createElement("div");
    w.className = "window";
    w.dataset.id = id;
    w.innerHTML = `
      <div class="w-head">
        <div class="w-title">${title}</div>
        <div class="w-actions"><button class="w-close" title="Kapat">×</button></div>
      </div>
      <div class="w-body">${html}</div>
    `;
    document.body.appendChild(w);
    centerWindow(w);
    // task
    const t = document.createElement("div");
    t.className = "task";
    t.textContent = title;
    t.dataset.id = id;
    t.onclick = ()=> { w.style.display = (w.style.display==="none"?"":"none"); };
    tasks.appendChild(t);
    // close
    w.querySelector(".w-close").onclick = ()=>{ w.remove(); t.remove(); };
    // drag
    dragWindow(w, w.querySelector(".w-head"));
    return w;
  }
  function centerWindow(w){
    const vw = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    const vh = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
    const ww = 540, wh = 380;
    w.style.width = ww+"px"; w.style.height = wh+"px";
    w.style.left = Math.round((vw-ww)/2)+"px";
    w.style.top = Math.round((vh-wh)/2.3)+"px";
  }
  function dragWindow(el, handle){
    let sx, sy, ox, oy, dragging=false;
    handle.style.cursor="move";
    handle.addEventListener("mousedown", (e)=>{
      dragging = true; sx = e.clientX; sy = e.clientY;
      const r = el.getBoundingClientRect();
      ox = r.left; oy = r.top;
      document.body.classList.add("dragging");
      e.preventDefault();
    });
    window.addEventListener("mousemove",(e)=>{
      if(!dragging) return;
      const nx = ox + (e.clientX - sx);
      const ny = oy + (e.clientY - sy);
      el.style.left = nx + "px"; el.style.top = ny + "px";
    });
    window.addEventListener("mouseup",()=>{
      if(dragging){ dragging=false; document.body.classList.remove("dragging"); }
    });
  }

  // -------- API helper --------
  async function api(action, body){
    let url = "api.php?action="+encodeURIComponent(action);
    const opt = body ? {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)} : {method:"GET"};
    const r = await fetch(url, opt);
    let j = null;
    try { j = await r.json(); } catch(e){ throw new Error("Geçersiz JSON yanıtı"); }
    if(!j || j.ok===false){ throw new Error((j && (j.error||j.detail)) || "İstek başarısız"); }
    return j;
  }

  // -------- Desktop items --------
  function iconEl(it){
    const div = document.createElement("div");
    div.className = "icon";
    const i = document.createElement("div");
    i.className = "i";
    i.innerHTML = (it.icon && it.icon.startsWith("fa:")) ? `<i class="${it.icon.slice(3)}"></i>` : `<i class="fa-regular fa-folder"></i>`;
    const t = document.createElement("div");
    t.className = "t";
    t.textContent = it.title || it.name || "Ad";
    div.appendChild(i); div.appendChild(t);
    div.title = it.title || it.name || "";
    if(it.type==="link" && it.url){
      div.ondblclick = ()=> window.open(it.url, "_blank");
    }else if(it.type==="folder"){
      div.ondblclick = ()=> openFolder(it);
      div.onclick = ()=> selectIcon(div);
    }
    return div;
  }
  function selectIcon(el){
    $$(".icon.selected").forEach(x=>x.classList.remove("selected"));
    el.classList.add("selected");
  }

  // -------- Folder window --------
  function openFolder(f){
    const w = makeWindow({title: f.title || f.name || "Klasör", html: `<div class="folder">Bu klasör şu an boş.</div>`});
    return w;
  }

  function clearGrid(){ grid.innerHTML=""; }

  async function loadAll(){
    clearGrid();
    try{
      const [F, L] = await Promise.all([api("list_folders"), api("list_links")]);
      const items = [];
      (F.folders||[]).forEach(f=>items.push({type:"folder", id:f.id, name:f.name, title:f.title, icon:f.icon||"fa:fa-regular fa-folder"}));
      (L.links||[]).forEach(l=>items.push({type:"link", id:l.id, name:l.name, title:l.title||l.name||l.url, icon:l.icon||"fa:fa-solid fa-link", url:l.url}));
      items.forEach(it=> grid.appendChild(iconEl(it)));
      status.textContent = `Klasör: ${(F.folders||[]).length} • Link: ${(L.links||[]).length}`;
    }catch(e){
      status.textContent = "Hata: "+e.message;
      console.error(e);
    }
  }

  // -------- Start menu --------
  function toggleStart(force){
    if(force===true){ startMenu.hidden = false; startOpen=true; return; }
    if(force===false){ startMenu.hidden = true; startOpen=false; return; }
    startOpen = !startOpen;
    startMenu.hidden = !startOpen;
    if(startOpen){
      // position next to start button
      const r = startBtn.getBoundingClientRect();
      startMenu.style.left = (r.left)+"px";
      startMenu.style.bottom = (document.documentElement.clientHeight - r.top + 6) + "px";
    }
  }
  startBtn.addEventListener("click", ()=> toggleStart());

  startMenu.addEventListener("click", async (e)=>{
    const it = e.target.closest(".sm-item"); if(!it) return;
    const act = it.dataset.act; await doAction(act);
    toggleStart(false);
  });

  // -------- Context menu --------
  function showCtx(x,y){
    ctx.hidden = false;
    ctx.style.left = x+"px"; ctx.style.top = y+"px";
  }
  function hideCtx(){ ctx.hidden = true; }
  grid.addEventListener("contextmenu",(e)=>{
    e.preventDefault();
    showCtx(e.clientX, e.clientY);
  });
  document.addEventListener("click",(e)=>{
    if(!e.target.closest("#ctx") && !e.target.closest("#startMenu") && !e.target.closest("#startBtn")){
      hideCtx(); toggleStart(false);
    }
  });
  ctx.addEventListener("click", async (e)=>{
    const it = e.target.closest(".citem"); if(!it) return;
    const act = it.dataset.act; hideCtx(); await doAction(act);
  });

  // -------- Actions --------
  async function doAction(act){
    if(act==="reload"){ await loadAll(); return; }
    if(act==="about"){ makeWindow({title:"Hakkında", html:`<div class="about">Pardus Web Masaüstü — DidimIndex teması</div>`}); return; }
    if(act==="settings"){ makeWindow({title:"Ayarlar", html:`<div class="about">Ayarlar yakında.</div>`}); return; }
    if(act==="logout"){ window.location.href = "?logout=1"; return; }
    if(act==="new-folder"){
      try{
        // read current, append, save
        const F = await api("list_folders");
        const now = Date.now().toString(36).slice(-6);
        const id = "f_"+now+Math.floor(Math.random()*1000).toString(36);
        const folders = (F.folders||[]).slice();
        folders.push({id, name:"Yeni Klasör", icon:"fa:fa-regular fa-folder|#8ab4f8"});
        await api("save_desk", {folders, links: (await api("list_links")).links||[]});
        await loadAll();
      }catch(e){
        alert("Klasör oluşturulamadı: "+e.message);
      }
      return;
    }
  }

  // -------- Boot --------
  document.addEventListener("DOMContentLoaded", ()=>{
    loadAll();
    reloadBtn.addEventListener("click", loadAll);
  });
})();