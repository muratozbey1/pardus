<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
require_once __DIR__ . '/../lib/init.php';
require_once __DIR__ . '/../lib/users.php';
require_once __DIR__ . '/../lib/admin_guard.php';
csrf_check();
$email = trim(strtolower((string)($_POST['email']??'')));
$pass  = (string)($_POST['password']??'');
users_bootstrap();
$u = user_by_email($email);
if(!$u || empty($u['pass_hash']) || !password_verify($pass, $u['pass_hash']) || ($u['role']??'user')!=='admin'){
  header('Location: login.php?err=1&'.DESKTOP_EMBED_PARAM.'=1'); exit;
}
admin_login_user($u);
// last login
$U=users_read(); for($i=0;$i<count($U['users']);$i++){ if((int)$U['users'][$i]['id']===(int)$u['id']){ $U['users'][$i]['last_login_at']=date('c'); break; } } users_write($U);
header('Location: index.php?'.DESKTOP_EMBED_PARAM.'=1'); exit;
