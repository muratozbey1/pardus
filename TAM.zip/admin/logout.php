<?php
require_once __DIR__ . '/../lib/init.php';
require_once __DIR__ . '/../lib/admin_guard.php';
admin_logout();
header('Location: login.php?'.DESKTOP_EMBED_PARAM.'=1');
