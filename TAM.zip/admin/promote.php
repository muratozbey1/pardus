<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
$BASE = dirname(__DIR__);
define('DATA_FILE', $BASE.'/data/users.json');
define('USERDATA_DIR', $BASE.'/userdata');
define('KEY_FILE', $BASE.'/data/admin.promote.key');
function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function load_users(){
  if(!is_file(DATA_FILE)){
    @mkdir(dirname(DATA_FILE), 0775, true);
    @file_put_contents(DATA_FILE, json_encode(['next_id'=>1,'users'=>[]], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
  }
  $raw = @file_get_contents(DATA_FILE);
  $j = $raw ? json_decode($raw, true) : null;
  if(!is_array($j)) $j = ['next_id'=>1,'users'=>[]];
  if(!isset($j['users']) || !is_array($j['users'])) $j['users']=[];
  if(!isset($j['next_id'])) $j['next_id']=1;
  return $j;
}
function save_users($j){
  $tmp = DATA_FILE.'.tmp';
  $fp = @fopen($tmp, 'wb'); if(!$fp) die('Yazılamadı');
  @flock($fp, LOCK_EX);
  @fwrite($fp, json_encode($j, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
  @fflush($fp); @flock($fp, LOCK_UN); @fclose($fp);
  @rename($tmp, DATA_FILE);
}
function make_username($email, $taken){
  $local = strtolower(preg_replace('/[^a-z0-9]+/i','-', (string)explode('@', $email)[0]));
  $local = trim($local,'-'); if($local==='') $local='user';
  $base = $local; $i=0;
  $exists = function($name) use ($taken){ foreach ($taken as $t) if (!empty($t['username']) && $t['username']===$name) return true; return false; };
  while($exists($local) || is_dir(USERDATA_DIR.'/'.$local)){
    $i++; $local = $base+'-'+str($i);
  }
  return $local;
}
function ensure_userdata_dir($uname){
  if(!is_dir(USERDATA_DIR)) @mkdir(USERDATA_DIR, 0775, true);
  $udir = USERDATA_DIR.'/'.$uname; if(!is_dir($udir)) @mkdir($udir, 0775, true);
}
$key_param = isset($_GET['key']) ? (string)$_GET['key'] : '';
$key_file  = is_file(KEY_FILE) ? trim((string)@file_get_contents(KEY_FILE)) : '';
$authed = ($key_param !== '' && $key_file !== '' && hash_equals($key_file, $key_param));
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!$authed){ http_response_code(403); exit('Yetkisiz'); }
  $email = trim(strtolower((string)($_POST['email']??'')));
  $pass  = (string)($_POST['password']??'');
  if(!$email || !$pass){ $msg='E-posta ve şifre zorunlu'; } else {
    $db = load_users();
    $idx = -1;
    foreach($db['users'] as $i=>$u){ if(strtolower($u['email']??'')===$email){ $idx=$i; break; } }
    if($idx===-1){
      $uname = make_username($email, $db['users']);
      $id = (int)$db['next_id']; $db['next_id']=$id+1;
      $user = [
        'id'=>$id, 'role'=>'admin', 'first_name'=>'Admin', 'last_name'=>'Root',
        'email'=>$email, 'phone'=>'', 'city'=>'', 'username'=>$uname,
        'pass_hash'=>password_hash($pass, PASSWORD_DEFAULT),
        'is_verified'=>1, 'created_at'=>date('c'), 'updated_at'=>date('c'), 'last_login_at'=>null
      ];
      $db['users'][] = $user; ensure_userdata_dir($uname);
      save_users($db);
      $ok = "Yeni admin oluşturuldu: ".esc($email);
    } else {
      $db['users'][$idx]['role'] = 'admin';
      $db['users'][$idx]['pass_hash'] = password_hash($pass, PASSWORD_DEFAULT);
      $db['users'][$idx]['is_verified'] = 1;
      $db['users'][$idx]['updated_at'] = date('c');
      $uname = $db['users'][$idx]['username'] ?? explode('@',$email)[0];
      $db['users'][$idx]['username'] = $uname;
      ensure_userdata_dir($uname);
      save_users($db);
      $ok = "Mevcut kullanıcı admin yapıldı ve şifre güncellendi: ".esc($email);
    }
  }
}
?><!doctype html><html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Promote</title>
<style>
  :root{--bg:#0f1115;--bg2:#1b1f28;--line:#2a2f3b;--fg:#e6e9ee;--mut:#9aa3b2}
  *{box-sizing:border-box}html,body{height:100%;margin:0;background:var(--bg);color:var(--fg);font-family:Inter,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}
  .center{min-height:100vh;display:grid;place-items:center;padding:20px}
  .card{width:420px;max-width:94vw;background:var(--bg2);border:1px solid var(--line);border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.35)}
  .card .hd{padding:12px 14px;border-bottom:1px solid var(--line);font-weight:800}
  .card .bd{padding:14px}
  label{display:block;margin-bottom:6px;font-size:12px;color:#c7d0df}
  input{width:100%;padding:10px;border-radius:10px;border:1px solid var(--line);background:#0f1115;color:#e6e9ee;font-size:14px}
  .btn{width:100%;padding:10px 12px;border-radius:10px;border:1px solid #3a4254;background:#1e2635;color:#fff;cursor:pointer;font-weight:600;margin-top:10px}
  .alert{padding:10px;border-radius:10px;margin-bottom:10px;background:#2a1f1f;border:1px solid #5e2d2d}
  .ok{background:#1f2a20;border-color:#2d5e39}
  .note{font-size:12px;color:#9aa3b2;margin-top:8px}
  .mono{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,"Liberation Mono","Courier New",monospace}
</style>
</head><body><div class="center"><div class="card">
  <div class="hd">Admin Promote (Tek Seferlik)</div>
  <div class="bd">
    <?php if(!$authed): ?>
      <div class="alert">Bu sayfayı kullanmak için <span class="mono">/pardus/data/admin.promote.key</span> dosyası oluşturup içine gizli KEY yazın ve sayfayı <span class="mono">?key=KEY</span> ile açın.</div>
    <?php endif; ?>
    <?php if(!empty($msg)): ?><div class="alert"><?=esc($msg)?></div><?php endif; ?>
    <?php if(!empty($ok)): ?><div class="alert ok"><?=esc($ok)?></div><?php endif; ?>
    <form method="post">
      <div><label>Doğrulama Anahtarı</label><input type="text" name="key" value="<?=esc($key_param)?>" placeholder="KEY"<?= $authed?' readonly':'' ?>></div>
      <div style="margin-top:8px"><label>Admin E-posta</label><input type="email" name="email" required value="<?=esc($_POST['email']??'')?>"></div>
      <div style="margin-top:8px"><label>Yeni Şifre</label><input type="text" name="password" required value="<?=esc($_POST['password']??'')?>"></div>
      <button class="btn" type="submit">Kaydet</button>
    </form>
    <div class="note" style="margin-top:10px">İşlemden sonra <span class="mono">/pardus/data/admin.promote.key</span> dosyasını siliniz.</div>
    <div class="note">Giriş: <span class="mono">/pardus/admin/login.php?inapp=1</span></div>
  </div>
</div></div></body></html>