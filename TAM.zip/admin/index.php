<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
require_once __DIR__ . '/../lib/init.php';
require_once __DIR__ . '/../lib/users.php';
require_once __DIR__ . '/../lib/admin_guard.php';

$me = admin_require(); // sadece admin girebilir

// simple KPIs
function kpi($n){ return number_format((float)$n, 0, ',', '.'); }
function bytes_h($b){ $u=['B','KB','MB','GB','TB']; $i=0; while($b>=1024 && $i<4){ $b/=1024; $i++; } return number_format($b,$i?1:0,',','.')." ".$u[$i]; }
function userdata_size($dir){ $t=0; if(is_dir($dir)){ $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)); foreach($it as $f){ $t += $f->getSize(); } } return $t; }

$U = users_read();
$totalUsers = count($U['users']??[]);
$verified = 0; foreach($U['users']??[] as $uu){ if(!empty($uu['is_verified'])) $verified++; }
$lastRegs = array_slice(array_reverse($U['users']??[]), 0, 7);
$disk = userdata_size(USERDATA_DIR);
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Panel</title><link rel="stylesheet" href="../assets/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer"/>
</head><body>
<div class="wrap">
  <aside class="aside">
    <div class="nav">
      <a href="?view=dashboard&<?=DESKTOP_EMBED_PARAM?>=1" class="<?=(($_GET['view']??'dashboard')==='dashboard')?'act':''?>">Gösterge Paneli</a>
      <a href="?view=users&<?=DESKTOP_EMBED_PARAM?>=1" class="<?=(($_GET['view']??'')==='users')?'act':''?>">Kullanıcılar</a>
      <a href="logout.php?<?=DESKTOP_EMBED_PARAM?>=1">Çıkış</a>
      <div style="margin-top:12px;color:#9aa3b2;font-size:12px">Giriş: <?=esc(($me['first_name']??'').' '.($me['last_name']??''))?> (admin)</div>
    </div>
  </aside>
  <main class="main">
    <?php $view=$_GET['view']??'dashboard'; if($view==='dashboard'): ?>
      <div class="kpi"><div class="n"><?=kpi($totalUsers)?></div><div class="t">Toplam Kullanıcı</div></div>
      <div class="kpi"><div class="n"><?=kpi($verified)?></div><div class="t">Doğrulanan</div></div>
      <div class="kpi"><div class="n"><?=bytes_h($disk)?></div><div class="t">Depolama</div></div>
      <div class="card" style="margin-top:12px"><div class="hd">Son Kayıtlar</div><div class="bd">
        <table><thead><tr><th>ID</th><th>Ad Soyad</th><th>E-posta</th><th>Onay</th><th>Oluşturma</th></tr></thead><tbody>
          <?php foreach($lastRegs as $u): $nm=trim(($u['first_name']??'').' '.($u['last_name']??'')); ?>
            <tr><td><?=$u['id']?></td><td><?=esc($nm)?></td><td class="mono"><?=esc($u['email']??'')?></td><td><?=!empty($u['is_verified'])?'✔':'—'?></td><td class="mono"><?=esc($u['created_at']??'')?></td></tr>
          <?php endforeach; ?>
        </tbody></table>
      </div></div>
    <?php elseif($view==='users'): ?>
      <div class="card"><div class="hd">Kullanıcılar</div><div class="bd">
        <table><thead><tr><th>ID</th><th>Ad Soyad</th><th>E-posta</th><th>Onay</th><th>Son Giriş</th></tr></thead><tbody>
          <?php foreach(($U['users']??[]) as $u): $nm=trim(($u['first_name']??'').' '.($u['last_name']??'')); ?>
            <tr>
              <td><?=$u['id']?></td>
              <td><?=esc($nm)?></td>
              <td class="mono"><?=esc($u['email']??'')?></td>
              <td><?=!empty($u['is_verified'])?'✔':'—'?></td>
              <td class="mono"><?=esc($u['last_login_at']??'—')?></td>
            </tr>
          <?php endforeach; ?>
        </tbody></table>
      </div></div>
    <?php endif; ?>
  </main>
</div>
</body></html>
