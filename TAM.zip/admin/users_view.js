(function(){
  if (window.initAdminUsersView) return;
  window.initAdminUsersView = function(container){
    const c = (typeof container==='string') ? document.querySelector(container) : container;
    if(!c) return;
    c.innerHTML = '<div class="card"><div class="hd">Kullanıcılar</div><div class="bd"><div id="tblWrap">Yükleniyor...</div></div></div>';
    fetch('users_list.php?inapp=1',{credentials:'same-origin'}).then(r=>r.json()).then(j=>{
      if(!j.ok) { c.querySelector('#tblWrap').textContent = j.error || 'Hata'; return; }
      const rows = (j.users||[]).map(u=>`<tr><td>${u.id}</td><td>${(u.name||'')}</td><td>${u.email}</td><td>${u.username}</td><td>${u.role}</td><td>${u.verified?'✔':'—'}</td><td>${u.last_login_at||'—'}</td><td>${u.created_at||''}</td></tr>`).join('');
      c.querySelector('#tblWrap').innerHTML = `<div style="overflow:auto"><table><thead><tr><th>ID</th><th>Ad Soyad</th><th>E-posta</th><th>Kullanıcı Adı</th><th>Rol</th><th>Onay</th><th>Son Giriş</th><th>Oluşturma</th></tr></thead><tbody>${rows}</tbody></table></div>`;
    }).catch(()=>{ c.querySelector('#tblWrap').textContent='Hata'; });
  };
})();