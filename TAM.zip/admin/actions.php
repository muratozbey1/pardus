<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
require_once __DIR__ . '/../lib/init.php';
require_once __DIR__ . '/../lib/users.php';
require_once __DIR__ . '/../lib/settings.php';
require_once __DIR__ . '/../lib/pages.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){ http_response_code(405); exit; }
csrf_check(); $me=current_user(); if(!$me || !is_admin($me)){ http_response_code(403); exit('Yetkisiz'); }
$act = isset($_POST['action']) ? (string)$_POST['action'] : '';
switch($act){
  case 'save_settings':
    $data=settings_read();
    $data['verify_enabled'] = isset($_POST['verify_enabled']) && $_POST['verify_enabled']==='1';
    $data['smtp']=array(
      'host'=>trim(isset($_POST['smtp_host'])?$_POST['smtp_host']:''),
      'port'=>(int)(isset($_POST['smtp_port'])?$_POST['smtp_port']:587),
      'secure'=>(string)(isset($_POST['smtp_secure'])?$_POST['smtp_secure']:'tls'),
      'user'=>trim(isset($_POST['smtp_user'])?$_POST['smtp_user']:''),
      'pass'=>(string)(isset($_POST['smtp_pass'])?$_POST['smtp_pass']:''),
      'from'=>trim(isset($_POST['smtp_from'])?$_POST['smtp_from']:''),
      'from_name'=>trim(isset($_POST['smtp_from_name'])?$_POST['smtp_from_name']:''),
    ); settings_write($data);
    header('Location: index.php?view=settings&'.DESKTOP_EMBED_PARAM.'=1'); exit;
  case 'save_page':
    $id = (int)(isset($_POST['id'])?$_POST['id']:0);
    $title = trim(isset($_POST['title'])?$_POST['title']:'');
    $slug = trim(isset($_POST['slug'])?$_POST['slug']:'');
    $html = isset($_POST['html'])?$_POST['html']:'';
    if(!$title || !$slug){ exit('Başlık ve slug zorunludur'); }
    require_once __DIR__ . '/../lib/pages.php';
    page_save($id?:null, $title, $slug, $html);
    header('Location: index.php?view=pages&'.DESKTOP_EMBED_PARAM.'=1'); exit;
  case 'delete_page':
    $id=(int)(isset($_POST['id'])?$_POST['id']:0); require_once __DIR__ . '/../lib/pages.php'; if($id) page_delete($id);
    header('Location: index.php?view=pages&'.DESKTOP_EMBED_PARAM.'=1'); exit;
  case 'toggle_verify':
    $id=(int)(isset($_POST['id'])?$_POST['id']:0); $U=users_read(); 
    for($i=0;$i<count($U['users']);$i++){ if((int)$U['users'][$i]['id'] === $id){ $U['users'][$i]['is_verified'] = !empty($U['users'][$i]['is_verified']) ? 0 : 1; $U['users'][$i]['updated_at']=date('c'); break; } }
    users_write($U); header('Location: index.php?view=users&'.DESKTOP_EMBED_PARAM.'=1'); exit;
  case 'reset_pass':
    $id=(int)(isset($_POST['id'])?$_POST['id']:0); $U=users_read(); $tmp='';
    for($i=0;$i<count($U['users']);$i++){ if((int)$U['users'][$i]['id'] === $id){ $tmp = bin2hex(random_bytes(4)); $U['users'][$i]['pass_hash']=password_hash($tmp, PASSWORD_DEFAULT); $U['users'][$i]['updated_at']=date('c'); break; } }
    users_write($U);
    ?><!doctype html><meta charset="utf-8"><link rel="stylesheet" href="../assets/admin.css"><body class="main"><div class="card"><div class="hd">Geçici Şifre</div><div class="bd"><p>Yeni geçici şifre:</p><p class="mono" style="font-size:18px"><?=esc($tmp?$tmp:'—')?></p><p><a class="btn" href="index.php?view=users&<?=DESKTOP_EMBED_PARAM?>=1">Geri</a></p></div></div></body><?php
    exit;
}
http_response_code(400); echo 'Geçersiz istek';
