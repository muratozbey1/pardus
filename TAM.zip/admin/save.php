<?php
declare(strict_types=1);
require_once __DIR__ . '/../lib/init.php';
require_once __DIR__ . '/../lib/settings.php';
require_once __DIR__ . '/../lib/users.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){ http_response_code(405); exit; }
csrf_check(); if(!current_user()){ http_response_code(403); exit('Yetkisiz'); }
$data=settings_read();
$data['verify_enabled'] = isset($_POST['verify_enabled']) && $_POST['verify_enabled']==='1';
$data['smtp']=[
  'host'=>trim((string)($_POST['smtp_host']??'')),
  'port'=>(int)($_POST['smtp_port']??587),
  'secure'=>(string)($_POST['smtp_secure']??'tls'),
  'user'=>trim((string)($_POST['smtp_user']??'')),
  'pass'=>(string)($_POST['smtp_pass']??''),
  'from'=>trim((string)($_POST['smtp_from']??'')),
  'from_name'=>trim((string)($_POST['smtp_from_name']??'')),
];
settings_write($data);
?><!doctype html><meta charset="utf-8"><link rel="stylesheet" href="../assets/auth.min.css"><body class="auth-mini"><div class="card"><h2>Ayarlar</h2><div class="body"><p>Ayarlar kaydedildi.</p><div class="btns"><a class="btn" href="index.php?<?=DESKTOP_EMBED_PARAM?>=1">Geri dön</a></div></div></div></body>
