<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
require_once __DIR__ . '/../lib/init.php';
require_once __DIR__ . '/../lib/users.php';
require_once __DIR__ . '/../lib/admin_guard.php';
require_desktop_embed('admin'); // optional (no redirect if EMBED_STRICT=false)
$csrf = csrf_token();
$err  = isset($_GET['err']) ? (string)$_GET['err'] : '';
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Girişi</title><link rel="stylesheet" href="../assets/admin_login.css"></head><body>
<div class="center">
  <div class="card">
    <div class="hd">Admin Girişi</div>
    <div class="bd">
      <?php if($err==='1'): ?><div class="alert">E-posta/şifre hatalı veya admin yetkiniz yok.</div><?php endif; ?>
      <form method="post" action="login_post.php">
        <input type="hidden" name="csrf" value="<?=$csrf?>">
        <div><label>E-posta (admin)</label><input name="email" type="email" required value="muratozbey@yahoo.com"></div>
        <div style="margin-top:8px"><label>Şifre</label><input name="password" type="password" required value="654123"></div>
        <button class="btn" type="submit">Giriş</button>
      </form>
    </div>
  </div>
</div>
</body></html>
