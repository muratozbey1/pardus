<?php
require_once __DIR__ . '/../lib/init.php';
require_once __DIR__ . '/../lib/users.php';
logout_user();
if(isset($_GET[DESKTOP_EMBED_PARAM]) && $_GET[DESKTOP_EMBED_PARAM]==='1'){ header('Location: login.php?'.DESKTOP_EMBED_PARAM.'=1'); }
else { header('Location: ../index.php'); }
