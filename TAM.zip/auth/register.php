<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
require_once __DIR__ . '/../lib/init.php';
require_once __DIR__ . '/../lib/settings.php';
require_desktop_embed('register');
$csrf = csrf_token(); $S=settings_read();
$err = isset($_GET['err'])?(string)$_GET['err']:'';
$ok  = isset($_GET['ok'])?(string)$_GET['ok']:'';
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Kayıt Ol</title><link rel="stylesheet" href="../assets/admin.css"></head><body>
<div class="form">
  <div class="title">Kullanıcı Oluştur</div>
  <?php if($err): ?><div class="alert"><?=esc($err)?></div><?php endif; ?>
  <?php if($ok==='1'): ?><div class="alert ok">Kayıt tamamlandı. Giriş yapabilirsiniz.</div><?php endif; ?>
  <form method="post" action="register_post.php">
    <input type="hidden" name="csrf" value="<?=$csrf?>">
    <div class="row"><label>Ad</label><input type="text" name="first_name" required></div>
    <div class="row"><label>Soyad</label><input type="text" name="last_name" required></div>
    <div class="row"><label>E-posta</label><input type="email" name="email" required></div>
    <div class="row"><label>Telefon</label><input type="text" name="phone"></div>
    <div class="row"><label>Şehir</label><input type="text" name="city"></div>
    <div class="row"><label>Şifre</label><input type="password" name="password" required></div>
    <div class="toolbar"><button class="btn" type="submit">Oluştur</button></div>
  </form>
  <div style="margin-top:10px"><a href="login.php?<?=DESKTOP_EMBED_PARAM?>=1">Girişe dön</a></div>
</div>
</body></html>
