<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
require_once __DIR__ . '/../lib/init.php';
require_once __DIR__ . '/../lib/users.php';
require_desktop_embed('login');
$csrf = csrf_token();
$err  = isset($_GET['err']) ? (string)$_GET['err'] : '';
$next = isset($_GET['next']) ? (string)$_GET['next'] : '';
?><!doctype html>
<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Giriş</title>
<link rel="stylesheet" href="../assets/auth.css">
</head><body>
<div class="login-wrap">
  <div class="row">
    <div class="card form">
      <div class="hd">Giriş</div>
      <div class="bd">
        <?php if($err==='1'): ?><div class="alert">E-posta veya şifre hatalı.</div><?php endif; ?>
        <form method="post" action="login_post.php">
          <input type="hidden" name="csrf" value="<?=$csrf?>">
          <input type="hidden" name="next" value="<?=esc($next)?>">
          <div class="rowi">
            <label>E-posta</label>
            <input id="email" name="email" type="email" required data-prefill="admin@local">
          </div>
          <div class="rowi">
            <label>Şifre</label>
            <div class="inline">
              <input id="password" name="password" type="password" required value="Admin123!">
              <span class="eye" id="toggleEye" title="Göster/Gizle">👁</span>
            </div>
          </div>
          <div class="toolbar"><button class="btn" type="submit">Giriş</button></div>
        </form>
        <div style="margin-top:10px"><a class="link" href="register.php?<?=DESKTOP_EMBED_PARAM?>=1">Hesabın yok mu? Kaydol</a></div>
      </div>
    </div>

    <div class="card cred">
      <div class="hd">Varsayılan Yönetici</div>
      <div class="bd">
        <div class="pair"><span class="small">E-posta:</span> <span class="mono">admin@local</span> <button class="btn copy" id="copyEmail">Kopyala</button></div>
        <div class="pair"><span class="small">Şifre:</span> <span class="mono">Admin123!</span> <button class="btn copy" id="copyPass">Kopyala</button></div>
        <div class="note">İlk girişten sonra şifreyi değiştirmen önerilir.</div>
      </div>
    </div>
  </div>
</div>
<script src="../assets/auth.js"></script>
</body></html>
