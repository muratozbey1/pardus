<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
if (session_status() === PHP_SESSION_NONE) { @session_start(['cookie_httponly'=>true, 'cookie_samesite'=>'Lax']); }
$BASE = dirname(__DIR__);
define('DATA_FILE', $BASE.'/data/users.json');
define('USERDATA_DIR', $BASE.'/userdata');

function db_load(){
  if(!is_dir(dirname(DATA_FILE))) @mkdir(dirname(DATA_FILE), 0775, true);
  if(!file_exists(DATA_FILE)) @file_put_contents(DATA_FILE, json_encode(['next_id'=>1,'users'=>[]], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
  $raw=@file_get_contents(DATA_FILE); $db=$raw?json_decode($raw,true):null;
  if(!is_array($db)) $db=['next_id'=>1,'users'=>[]];
  if(!isset($db['users']) || !is_array($db['users'])) $db['users']=[];
  if(!isset($db['next_id'])) $db['next_id']=1;
  return $db;
}
function db_save($db){
  $tmp=DATA_FILE.'.tmp'; $fp=@fopen($tmp,'wb'); if(!$fp) { http_response_code(500); exit('Yazılamadı'); }
  @flock($fp,LOCK_EX); @fwrite($fp,json_encode($db,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)); @fflush($fp);
  @flock($fp,LOCK_UN); @fclose($fp); @rename($tmp, DATA_FILE);
}
function user_by_id($db,$id){ foreach($db['users'] as $u){ if((int)($u['id']??0)===(int)$id) return $u; } return null; }
function user_by_email($db,$e){ foreach($db['users'] as $u){ if(strtolower($u['email']??'')===strtolower($e)) return $u; } return null; }
function username_make($email,$db){
  $local=strtolower(preg_replace('/[^a-z0-9]+/i','-',explode('@',$email)[0]??'')); $local=trim($local,'-'); if($local==='') $local='user';
  $base=$local; $i=0; $exists=function($n) use($db){ foreach($db['users'] as $t){ if(($t['username']??'')===$n) return true; } return false; };
  while($exists($local) || is_dir(USERDATA_DIR.'/'.$local)){ $i++; $local=$base.'-'.$i; }
  return $local;
}
function ensure_userdir($uname){
  if(!is_dir(USERDATA_DIR)) @mkdir(USERDATA_DIR,0775,true);
  $u = USERDATA_DIR.'/'.$uname; if(!is_dir($u)) @mkdir($u,0775,true);
}
function current_user($db=null){
  if (session_status() === PHP_SESSION_NONE) @session_start();
  $id = $_SESSION['uid'] ?? 0;
  if(!$id) return null;
  if($db===null) $db=db_load();
  return user_by_id($db, (int)$id);
}
function is_admin($u){ return $u && ($u['role']??'user')==='admin'; }
function json_send($arr){ header('Content-Type: application/json; charset=UTF-8'); echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit; }

// Basit profil güncelleme + avatar upload (2MB sınır)
$db = db_load(); $me = current_user($db);
if(!$me){ json_send(['ok'=>false,'error'=>'Giriş gerekli']); }

$first=trim((string)($_POST['first_name']??''));
$last =trim((string)($_POST['last_name']??''));
$phone=trim((string)($_POST['phone']??''));
$city =trim((string)($_POST['city']??''));
$avatar_preset = trim((string)($_POST['avatar_preset']??'')); // preset:xxx
$uidx = -1;
for($i=0;$i<count($db['users']);$i++){ if((int)($db['users'][$i]['id']??0)===(int)$me['id']){ $uidx=$i; break; } }
if($uidx<0){ json_send(['ok'=>false,'error'=>'Kullanıcı bulunamadı']); }

if($first!=='') $db['users'][$uidx]['first_name']=$first;
if($last!=='') $db['users'][$uidx]['last_name']=$last;
$db['users'][$uidx]['phone']=$phone;
$db['users'][$uidx]['city']=$city;

// preset seçildiyse kaydet
if($avatar_preset!==''){
  $db['users'][$uidx]['avatar'] = 'preset:'.preg_replace('/[^a-z0-9_-]+/i','', $avatar_preset);
}

// file upload?
if(isset($_FILES['avatar_file']) && is_uploaded_file($_FILES['avatar_file']['tmp_name'])){
  $tmp = $_FILES['avatar_file']['tmp_name'];
  $info = @getimagesize($tmp);
  if(!$info){ json_send(['ok'=>false,'error'=>'Geçersiz resim']); }
  $mime = $info['mime'];
  $ext = 'png';
  if($mime==='image/png') $ext='png';
  elseif($mime==='image/jpeg') $ext='jpg';
  elseif($mime==='image/webp') $ext='webp';
  else json_send(['ok'=>false,'error'=>'Sadece PNG/JPG/WebP']);
  if($_FILES['avatar_file']['size']>2*1024*1024) json_send(['ok'=>false,'error'=>'Max 2MB']);

  $uname = $db['users'][$uidx]['username']??null; if(!$uname) json_send(['ok'=>false,'error'=>'Klasör bulunamadı']);
  $udir = USERDATA_DIR.'/'.$uname; if(!is_dir($udir)) @mkdir($udir,0775,true);
  // sil eski avatar.*
  foreach(glob($udir.'/avatar.*') as $old) @unlink($old);
  $target = $udir.'/avatar.'.$ext;
  if(!@move_uploaded_file($tmp, $target)) json_send(['ok'=>false,'error'=>'Kaydedilemedi']);
  $db['users'][$uidx]['avatar'] = 'file:'.$ext;
}

$db['users'][$uidx]['updated_at'] = date('c');
db_save($db);

json_send(['ok'=>true,'message'=>'Profil güncellendi']);
