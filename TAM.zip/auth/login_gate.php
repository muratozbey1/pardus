<?php
// auth/login_gate.php — disallow direct access; force desktop embed
@ini_set('display_errors','1'); @error_reporting(E_ALL);
$inapp = isset($_GET['inapp']) ? (int)$_GET['inapp'] : 0;
$ref = $_SERVER['HTTP_REFERER'] ?? '';
$ok = ($inapp===1) || (strpos($ref, '/pardus/index.php')!==false);
if(!$ok){
  header('Location: ../index.php?open=login'); exit;
}