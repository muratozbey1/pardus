<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
header('Content-Type: application/json; charset=UTF-8');
if (session_status() === PHP_SESSION_NONE) { @session_start(['cookie_httponly'=>true, 'cookie_samesite'=>'Lax']); }

$BASE = dirname(__DIR__);
define('DATA_FILE', $BASE.'/data/users.json');
define('USERDATA_DIR', $BASE.'/userdata');

function j($ok,$msg='',$extra=[]){ echo json_encode(array_merge(['ok'=>$ok,'message'=>$msg],$extra), JSON_UNESCAPED_UNICODE); exit; }
function db_load(){
  if(!is_dir(dirname(DATA_FILE))) @mkdir(dirname(DATA_FILE), 0775, true);
  if(!file_exists(DATA_FILE)) @file_put_contents(DATA_FILE, json_encode(['next_id'=>1,'users'=>[]], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
  $raw=@file_get_contents(DATA_FILE); $db=$raw?json_decode($raw,true):null;
  if(!is_array($db)) $db=['next_id'=>1,'users'=>[]];
  if(!isset($db['users']) || !is_array($db['users'])) $db['users']=[];
  if(!isset($db['next_id'])) $db['next_id']=1;
  return $db;
}
function db_save($db){
  $tmp=DATA_FILE.'.tmp'; $fp=@fopen($tmp,'wb'); if(!$fp) j(false,'Yazılamadı');
  @flock($fp,LOCK_EX); @fwrite($fp,json_encode($db,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)); @fflush($fp);
  @flock($fp,LOCK_UN); @fclose($fp); @rename($tmp, DATA_FILE);
}
function username_make($email,$db){
  $local=strtolower(preg_replace('/[^a-z0-9]+/i','-',explode('@',$email)[0]??'')); $local=trim($local,'-'); if($local==='') $local='user';
  $base=$local; $i=0; $exists=function($n) use($db){ foreach($db['users'] as $t){ if(($t['username']??'')===$n) return true; } return false; };
  while($exists($local) || is_dir(USERDATA_DIR.'/'.$local)){ $i++; $local=$base.'-'.$i; }
  return $local;
}
function ensure_userdir($uname){
  if(!is_dir(USERDATA_DIR)) @mkdir(USERDATA_DIR,0775,true);
  $u = USERDATA_DIR.'/'.$uname; if(!is_dir($u)) @mkdir($u,0775,true);
}

$first=trim((string)($_POST['first_name']??''));
$last =trim((string)($_POST['last_name']??''));
$email=strtolower(trim((string)($_POST['email']??'')));
$pass =(string)($_POST['password']??'');
$phone=trim((string)($_POST['phone']??''));
$city =trim((string)($_POST['city']??''));

if(!$first||!$last||!$email||!$pass) j(false,'Zorunlu alanlar eksik');

$db=db_load();
foreach($db['users'] as $u){ if(strtolower($u['email']??'')===$email) j(false,'Bu e-posta zaten kayıtlı'); }

$username=username_make($email,$db);
$id=(int)$db['next_id']; $db['next_id']=$id+1;
$rec=[
  'id'=>$id,'role'=>'user','first_name'=>$first,'last_name'=>$last,'email'=>$email,'phone'=>$phone,'city'=>$city,
  'username'=>$username,
  // MD5 ile saklama (isteğin doğrultusunda)
  'pass_md5'=>md5($pass),
  'is_verified'=>1,'created_at'=>date('c'),'updated_at'=>date('c'),'last_login_at'=>null,
  'avatar'=>null
];
$db['users'][]=$rec; db_save($db); ensure_userdir($username);

// AUTO LOGIN
$_SESSION['uid']=$id;

j(true,'Kayıt tamamlandı ve giriş yapıldı',['username'=>$username]);
