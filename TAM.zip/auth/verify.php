<?php
declare(strict_types=1);
require_once __DIR__ . '/../lib/init.php';
require_once __DIR__ . '/../lib/users.php';
$email=(string)($_GET['email']??''); $token=(string)($_GET['token']??'');
$u = ($email && $token) ? user_by_token($email,$token) : null; $ok=false;
if($u){ set_verified($u); $ok=true; }
?><!doctype html><meta charset="utf-8"><link rel="stylesheet" href="../assets/auth.min.css"><body class="auth-mini"><div class="card"><h2><?=$ok?'Hesap aktifleştirildi':'Onay başarısız'?></h2><div class="body"><?=$ok?'<p>Artık giriş yapabilirsin.</p><div class="btns"><a class="btn" href="login.php?'.DESKTOP_EMBED_PARAM.'=1">Giriş</a></div>':'<p>Link geçersiz ya da daha önce kullanılmış olabilir.</p>'?></div></div></body>
