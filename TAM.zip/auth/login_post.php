<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
require_once __DIR__ . '/../lib/init.php';
require_once __DIR__ . '/../lib/users.php';

// CSRF zorunlu değil, sadeleştirildi
$email = trim(strtolower((string)($_POST['email']??'')));
$pass  = (string)($_POST['password']??'');
$next  = (string)($_POST['next']??'');

users_bootstrap();
$u = user_by_email($email);

$ok = false;
if($u){
  if(!empty($u['pass_hash'])){
    $ok = password_verify($pass, $u['pass_hash']);
  } elseif (!empty($u['pass_md5'])){
    $ok = (md5($pass) === $u['pass_md5']);
  }
}
if(!$ok){
  header('Location: login.php?err=1&'.DESKTOP_EMBED_PARAM.'=1'); exit;
}

// giriş + last login
login_user_by_id((int)$u['id']);
$U=users_read(); for($i=0;$i<count($U['users']);$i++){ if((int)$U['users'][$i]['id']===(int)$u['id']){ $U['users'][$i]['last_login_at']=date('c'); break; } } users_write($U);

// yönlendirme
if($next && strpos($next,'http')!==0){ header('Location: '.$next); exit; }
if(isset($u['role']) && $u['role']==='admin'){ header('Location: ../admin/index.php?'.DESKTOP_EMBED_PARAM.'=1'); exit; }
header('Location: ../index.php'); exit;
