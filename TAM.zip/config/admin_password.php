<?php
return ['algo'=>'sha256','hash'=>'a097d770d21d3cc9e26c4a39e4be00721f001d1e475ae67c2519043b5fb43fca'];
