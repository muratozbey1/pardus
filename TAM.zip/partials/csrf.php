<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
require_once __DIR__ . '/../lib/init.php';
header('Content-Type: application/json; charset=UTF-8');
echo json_encode(['ok'=>true,'csrf'=>csrf_token()], JSON_UNESCAPED_UNICODE);
