<?php
@ini_set('display_errors','1'); @error_reporting(E_ALL);
if (session_status() === PHP_SESSION_NONE) { @session_start(['cookie_httponly'=>true, 'cookie_samesite'=>'Lax']); }
$BASE = dirname(__DIR__);
$users_file = $BASE.'/data/users.json';
$U = ['users'=>[]];
if (file_exists($users_file)) {
  $raw=@file_get_contents($users_file); $tmp=$raw?json_decode($raw,true):null; if(is_array($tmp)) $U=$tmp;
}
$uid = $_SESSION['uid'] ?? 0;
$me = null;
if ($uid) {
  foreach($U['users'] as $u){ if((int)($u['id']??0)===(int)$uid){ $me=$u; break; } }
}
$name = 'Murat Özbey';
$avatar_url = null;
if ($me) {
  $fn = trim(($me['first_name']??'').' '.($me['last_name']??''));
  if ($fn!=='') $name = $fn;
  if (!empty($me['avatar']) && strpos($me['avatar'],'file:')===0) {
    $ext = substr($me['avatar'],5);
    $un = $me['username'] ?? '';
    $avatar_path = '/pardus/userdata/'.$un.'/avatar.'.$ext;
    $avatar_url = $avatar_path;
  }
}
header('Content-Type: application/javascript; charset=UTF-8');
?>
window.SOFTDESK_USER = <?php echo json_encode([
  'logged' => !!$me,
  'id' => $me['id'] ?? null,
  'email' => $me['email'] ?? null,
  'username' => $me['username'] ?? null,
  'role' => $me['role'] ?? 'guest',
  'name' => $name,
  'avatar_url' => $avatar_url,
], JSON_UNESCAPED_UNICODE); ?>;
